#!/bin/bash
../TransComb -b ./test.bam -s unstranded -l 200
