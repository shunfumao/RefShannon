#include<vector>
//#include"Find_junc.h"
using namespace std;
vector<int> False_junc(vector<int> exon_l,vector<int> exon_r){
	vector<int> false_junc;
	for(int i=1;i<exon_l.size();i++){
		if(exon_l[i]-exon_r[i-1]==1) false_junc.push_back(exon_r[i-1]);
//		cout<<exon_l[i-1]<<" "<<exon_r[i]<<endl;
	}
	return false_junc;
}
vector<double>  False_junc_cov(vector<int> false_junc,vector<int> seg_l,vector<int>seg_r,vector<int>seg_NH){
     vector<double> false_junc_cov;
     for(int i=0;i<false_junc.size();i++){false_junc_cov.push_back(0);}
     for(int k=0;k<seg_l.size();k++){
          for(int i=0;i<false_junc.size();i++){
              if(seg_l[k]<=false_junc[i] && seg_r[k]-1>=false_junc[i]) {
                  double d=1.0000/seg_NH[k];
                  false_junc_cov[i]=false_junc_cov[i]+d;
              }
          }
     }
     return false_junc_cov;
}
/*
vector<double> false_junc_cov(vector<int> false_junc,int from,int to,vector<int> v_rstart,vector<string>v_map,vector<int> v_NH){
	vector<double> false_junc_cov;
//cout<<false_junc.size()<<endl;
	for(int i=0;i<false_junc.size();i++){false_junc_cov.push_back(0);}
	for(int j=from;j<=to;j++){
  	    vector<int> junc_l,junc_r,seg_l,seg_r;
	    int last_map;
 	    Find_junc find_seg;
  	    find_seg.find_junc(v_rstart[j],v_map[j]);
	    junc_l=find_seg.get_junc_l();
	    junc_r=find_seg.get_junc_r();
	    last_map=find_seg.get_last_map();
	    seg_l.push_back(v_rstart[j]);
	if(junc_l.size()>0){
	    seg_r.push_back(junc_l[0]-1);
	    for(int k=1;k<junc_l.size();k++){
		seg_l.push_back(junc_r[k-1]);
		seg_r.push_back(junc_l[k]-1);
	    }
	    seg_l.push_back(junc_r.back());
	    seg_r.push_back(v_rstart[j]+last_map-1);
	}
	else seg_r.push_back(v_rstart[j]+last_map-1);
	    for(int k=0;k<seg_l.size();k++){
		for(int i=0;i<false_junc.size();i++){
		    if(seg_l[k]<=false_junc[i] && seg_r[k]-1>=false_junc[i]) {
			double d=1.0000/v_NH[j];
			false_junc_cov[i]=false_junc_cov[i]+d;
		    }
		}
	    }    
	}

	for(int i=0;i<false_junc_cov.size();i++){
//		cout<<false_junc_cov[i]<<endl;
		if(false_junc_cov[i]<1) false_junc_cov[i]=1;
//cout<<false_junc[i]<<endl;
	}

	return false_junc_cov;
}*/
