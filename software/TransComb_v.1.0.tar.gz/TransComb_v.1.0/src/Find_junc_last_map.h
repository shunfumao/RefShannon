#include<vector>
#include<string>
using namespace std;
class Find_junc{
    private: vector<int> read_junc_l;vector<int> read_junc_r;
	     vector<int> read_seg_l;vector<int> read_seg_r;
	     int last_map;
    public:
             void find_junc(int v_rstart, string v_map);
             vector<int> get_read_junc_l();
             vector<int> get_read_junc_r();
	     vector<int> get_read_seg_l();
	     vector<int> get_read_seg_r();
             int get_last_map();

};
    void Find_junc::find_junc(int v_rstart, string v_map){
        int num1=0;
        int num2=0;
        int sum=0;
        string s=v_map;
        for(int a=0;a<s.length();a++){
            if(s[a]<='9'&&s[a]>='0'){
                int sa=(int)(s[a]-'0');
                sum=sum*10+sa;
            }
            else{
                if(s[a]=='M'||s[a]=='D'){
                    num2=num2+sum;
                    num1=num1+sum;
                    sum=0;
                }
                if(s[a]=='N'){//发现junction

                    num2=num2+sum;
                    read_junc_l.push_back(v_rstart+num1);
                    read_junc_r.push_back(v_rstart+num2);
                    num1=num1+sum;
                    sum=0;
                }
                if(s[a]!='N'&&s[a]!='M'&&s[a]!='D') sum=0;
            }
        }
        last_map=num1;
	read_seg_l.push_back(v_rstart);
	if(read_junc_l.size()>0){
	    read_seg_r.push_back(read_junc_l[0]-1);
	    for(int k=1;k<read_junc_l.size();k++){
                read_seg_l.push_back(read_junc_r[k-1]);
                read_seg_r.push_back(read_junc_l[k]-1);
            }
	    read_seg_l.push_back(read_junc_r.back());
	    read_seg_r.push_back(v_rstart+last_map-1);
	}
	else read_seg_r.push_back(v_rstart+last_map-1);
    }
    vector<int>Find_junc::get_read_junc_l(){return read_junc_l;}
    vector<int>Find_junc::get_read_junc_r(){return read_junc_r;}
    vector<int>Find_junc::get_read_seg_l(){return read_seg_l;}
    vector<int>Find_junc::get_read_seg_r(){return read_seg_r;}
    int Find_junc::get_last_map(){return last_map;}
