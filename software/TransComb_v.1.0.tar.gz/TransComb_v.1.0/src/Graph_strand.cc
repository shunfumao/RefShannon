#include<iostream>
#include<string>
#include<algorithm>
#include<vector>
#include<fstream>
#include<sstream>
#include<map>
#include<cstring>
#include<stdlib.h>
#include"process.h"
#include"graph_division.h"
//#include"describe_graph.h"
	
using namespace std;

	string FILTER;
	string LENGTH;
	int Path_length;
	string DEL_Junc_1;double COV_RATE;
	string DEL_Junc_2;double RATE;
	string Graph_Length;int gr_length;
	string Trim;int trim;
	string Exon_Combine;int MERGE_PARA;
	string seed_filter;float SEED_Filter;
	string Anchor_Length; int anchor_length;
	string Multi_Map_Frac; float multi_map_frac;
	double Mul_RATE=0.01;
	double SEP_EXON_RATE=0.25;
	size_t READ_LENGTH=0;
	int rg_index = 0;
	int trans_id;
	double multi;
	string s_all_line;
	size_t all_line;
	void get_multi(string name){
		const char* file=name.c_str();
		size_t start=0;
		ifstream in(file);
		istringstream istr;
		string s;
		while(getline(in,s)){
			start++;
			string read_map,read_ch,read_pair,read_nh,read_id,flag,read_start,read_qual,pair_site;
	                istr.str(s);
                	string s_no,seq;
        	        istr>>read_id>>flag>>read_ch>>read_start>>read_qual>>read_map>>read_pair>>pair_site>>s_no>>seq;
                	while(istr>>s_no){
	                   if(Has_nh(s_no)){read_nh=s_no;break;}
			}
        	        istr.clear();
	                if(Has_nh(read_nh)){
				READ_LENGTH=seq.length();
				size_t real_line=all_line-start+1;
				multi=1000000000/double(READ_LENGTH)/double(real_line);
				return;
			}
		}
	}
int main(int argc,char*argv[]){
    ifstream in_file(argv[1]);
    ifstream in_file_s(argv[1]);
    int strand=0;
    int line=0;
    string s_strand;
    while(getline(in_file_s,s_strand)){
    	line++;
    }
    char * out_name=argv[2];
    FILTER=argv[3];
    LENGTH=argv[4];Path_length=atoi(LENGTH.c_str());
    DEL_Junc_1=argv[5];COV_RATE=(double)atof(DEL_Junc_1.c_str());
    DEL_Junc_2=argv[6];RATE=(double)atof(DEL_Junc_2.c_str());
    Graph_Length=argv[7];gr_length=atoi(Graph_Length.c_str());
    Trim=argv[8];trim=atoi(Trim.c_str());
    Exon_Combine=argv[9];MERGE_PARA=atoi(Exon_Combine.c_str());
    seed_filter=argv[10];SEED_Filter=atoi(seed_filter.c_str());
    Anchor_Length=argv[11]; anchor_length=atoi(Anchor_Length.c_str());
    Multi_Map_Frac=argv[12]; multi_map_frac=atof(Multi_Map_Frac.c_str());
    s_all_line=argv[13]; all_line=atof(s_all_line.c_str());//NEW
    string cov_filter;//=(argv[3]);
    istringstream istr_file;
    string s_file;
    while(getline(in_file,s_file)){
	    strand++;
	    string sss;
    	    istr_file.str(s_file);
	    istr_file>>sss;
	    istr_file.clear();
	    const char * file=sss.c_str();
	    ifstream in(file);
	    istringstream istr;
	    string s;
	    vector<int> exon_l,exon_r,junc_l,junc_r,seg_l,seg_r,seg_NH;
	    vector<double> exon_cov,junc_cov,v_Gene,junc_cov_plus,junc_cov_minus;
	    vector<int> read_beg,read_fin,Read_nh;
	    int XS_plus=0;
	    int XS_minus=0;
	    map<vector<int>,double> Read;//vector<double> Read_cov;
	    vector<vector<int> > Read_seg;vector<double> Read_cov;
	    int max_map=0;
	    int gene_l;
	    vector<string> ch_note;//判断一个染色体是否结束
	    multimap <string,vector<string> > m_id_map;
	    typedef multimap <string,vector<string> >::iterator iter;
	    get_multi(sss);//NEW
	    while(getline(in,s)){
		int flag,read_start,pair_site,read_qual;
		int xs_flag;
		int read_NH=0;
		string read_map,read_ch,read_pair,read_nh,read_id;
		istr.str(s);
		string s_no;
		istr>>read_id>>flag>>read_ch>>read_start>>read_qual>>read_map>>read_pair>>pair_site>>s_no;
		vector<string> v_find_nh;
		while(istr>>s_no){
		   if(Has_nh(s_no)){read_nh=s_no;break;}
		   if(line==1 && Has_XS_A(s_no)){
			if(s_no[s_no.length()-1]=='+') {XS_plus++;xs_flag=1;}
			else {XS_minus++;xs_flag=0;}
		   }
		}
		istr.clear();
	    	if(Has_nh(read_nh) || read_id=="end" ){
		    for(int j=5;j<read_nh.length();j++){
		            int num=(int)(read_nh[j]-'0');
		            read_NH=read_NH*10+num;
	            }
		    if(read_id!="end"){read_id.erase(read_id.end()-1);read_id.erase(read_id.end()-1);}
		    vector<int> read_junc_l,read_junc_r,read_seg_l,read_seg_r;
	  	    int read_last_site;
		    vector<int> read_temp;
		    Find_junc find_junction;//发现当前read中的junction，并且计算最后map位点，并且计算当前read的seg
		    find_junction.find_junc(read_start,read_map);
		    read_junc_l=find_junction.get_read_junc_l();
		    read_junc_r=find_junction.get_read_junc_r();
		    read_seg_l=find_junction.get_read_seg_l();
		    read_seg_r=find_junction.get_read_seg_r();
		    read_last_site=find_junction.get_last_map()+read_start-1;
		    if(read_id=="end" || (read_seg_r[0]-read_seg_l[0]+1>anchor_length && read_seg_r.back()-read_seg_l.back()+1>anchor_length)){
			//*************************
			if(ch_note.size()==0){
                                ch_note.push_back(read_ch);
                                gene_l=read_start;
                                max_map=read_last_site;
                        }
			if(read_ch == ch_note.back() && read_start<=max_map+MERGE_PARA && read_id!="end"){//�current read in this gene!
			  for(int i=0;i<read_junc_l.size();i++){//确定junction
			    	int z=0;
			    if(junc_l.size()==0){
	    	 	    	junc_l.push_back(read_junc_l[i]);
				junc_r.push_back(read_junc_r[i]);
				double d=1.0000/(read_NH*read_NH);
				junc_cov.push_back(d);
				if(xs_flag==1) {junc_cov_plus.push_back(d);junc_cov_minus.push_back(0);}//plus_cov
				else {junc_cov_plus.push_back(0);junc_cov_minus.push_back(d);}
				z++;
		    	    }
		    	    if(junc_l.size()>0&&z==0){
				if(read_junc_l[i]==junc_l.back() && read_junc_r[i]==junc_r.back()){
			    	double d=1.00000/(read_NH*read_NH);
			    	junc_cov.back()=junc_cov.back()+d;
				if(xs_flag==1) {junc_cov_plus.back()=junc_cov_plus.back()+d;junc_cov_minus.back()=junc_cov_minus.back()+0;}//plus_cov
				else {junc_cov_plus.back()=junc_cov_plus.back()+0;junc_cov_minus.back()=junc_cov_minus.back()+d;}
				}
				if(read_junc_l[i]>junc_l.back()||(read_junc_l[i]==junc_l.back()&&read_junc_r[i]>junc_r.back())){
			    	    junc_l.push_back(read_junc_l[i]);
				    junc_r.push_back(read_junc_r[i]);
				    double d=1.0000/(read_NH*read_NH);
				    junc_cov.push_back(d);
				    if(xs_flag==1) {junc_cov_plus.push_back(d);junc_cov_minus.push_back(0);}//plus_cov
				    else {junc_cov_plus.push_back(0);junc_cov_minus.push_back(d);}
				}
				if(read_junc_l[i]<junc_l.back()||(read_junc_l[i]==junc_l.back()&&read_junc_r[i]<junc_r.back())){
				    for(int k=junc_l.size()-1;k>=0;k--){
					if(read_junc_l[i]==junc_l[k]&&read_junc_r[i]==junc_r[k]){
					    double d=1.00000/(read_NH*read_NH);
					    junc_cov[k]=junc_cov[k]+d;
					    if(xs_flag==1) {junc_cov_plus[k]=junc_cov_plus[k]+d;junc_cov_minus[k]=junc_cov_minus[k]+0;}//plus_cov
					    else {junc_cov_plus[k]=junc_cov_plus[k]+0;junc_cov_minus[k]=junc_cov_minus[k]+d;}
					    break;
					}
					if(read_junc_l[i]>junc_l[k]||(read_junc_l[i]==junc_l[k]&&read_junc_r[i]>junc_r[k])){
					    junc_l=insert(junc_l,k+1,read_junc_l[i]);
					    junc_r=insert(junc_r,k+1,read_junc_r[i]);
				 	    double d=1.00000/(read_NH*read_NH);
					    junc_cov=insert_d(junc_cov,k+1,d);
					    if(xs_flag==1) {junc_cov_plus=insert_d(junc_cov_plus,k+1,d);junc_cov_minus=insert_d(junc_cov_minus,k+1,0);}//plus_cov
					    else {junc_cov_plus=insert_d(junc_cov_plus,k+1,0);junc_cov_minus=insert_d(junc_cov_minus,k+1,d);}
					    break;
					}
					if(k==0){
					    vector<int> junc_lt,junc_rt;vector<double>junc_covt,junc_cov_plust,junc_cov_minust;
					    junc_lt=junc_l;junc_rt=junc_r;junc_covt=junc_cov;junc_cov_plust=junc_cov_plus;junc_cov_minust=junc_cov_minus;
					    junc_l.clear();junc_r.clear();junc_cov.clear();junc_cov_plus.clear();junc_cov_minus.clear();
					    junc_l.push_back(read_junc_l[i]);
					    junc_r.push_back(read_junc_r[i]);
					    double d=1.00000/(read_NH*read_NH);
					    junc_cov.push_back(d);
					    if(xs_flag==1){ junc_cov_plus.push_back(d);junc_cov_minus.push_back(0);}//plus_cov
					    else {junc_cov_plus.push_back(0);junc_cov_minus.push_back(d);}
					    for(int m=0;m<junc_lt.size();m++){
		                                  junc_l.push_back(junc_lt[m]);
		                                  junc_r.push_back(junc_rt[m]);
		                                  junc_cov.push_back(junc_covt[m]);
						  junc_cov_plus.push_back(junc_cov_plust[m]);//plus_cov
						  junc_cov_minus.push_back(junc_cov_minust[m]);
		                            }
					}
			    	    }	
				}
			    }
			  }
			/*
	        	if(ch_note.size()==0){
			    	ch_note.push_back(read_ch);
		        	gene_l=read_start;
				max_map=read_last_site;
			}
			*/
			//if(read_ch == ch_note.back() && read_start<=max_map+MERGE_PARA && read_id!="end"){//�current read in this gene!
		 	    read_beg.push_back(read_start);read_fin.push_back(read_last_site);Read_nh.push_back(read_NH);
			    if(read_last_site>max_map) max_map=read_last_site;
			    for(int i=v_Gene.size();i<=max_map-gene_l;i++) v_Gene.push_back(0);
			    for(int j=0;j<read_seg_l.size();j++){
				for(int k=read_seg_l[j]-gene_l;k<=read_seg_r[j]-gene_l;k++){
				    double d=1.00000/(read_NH*read_NH);
				    v_Gene[k]=v_Gene[k]+d;
				}
				seg_l.push_back(read_seg_l[j]);
				seg_r.push_back(read_seg_r[j]);
				seg_NH.push_back(read_NH*read_NH);
			    }
			    if(read_NH==1 && read_pair=="="){//edge_node_pair
		                vector<string> start_map;
		                stringstream start_to_string;//
		                start_to_string<<read_start;
		                string start;
		                start_to_string>>start;
		                start_map.push_back(start);
		                start_map.push_back(read_map);
		                m_id_map.insert(pair<string,vector<string> > (read_id,start_map));
		            }
			}
			else{//current read is not in this gene process it;
	
		if(max_map-gene_l>gr_length ){
				    while(junc_l.size()>0&&(junc_l.back()>max_map || junc_r.back()<gene_l)){junc_l.pop_back();junc_r.pop_back();junc_cov.pop_back();junc_cov_plus.pop_back();junc_cov_minus.pop_back();}
//cout<<" **" <<junc_cov.size()<<" "<<junc_cov_plus.size()<<" "<<junc_cov_minus.size()<<endl;
//for(int i=0;i<junc_l.size();i++) cout<<junc_cov[i]<<" "<<junc_cov_plus[i]<<" "<<junc_cov_minus[i]<<" "<<junc_cov_plus[i]+junc_cov_minus[i]<<endl;

  		     //*********************************************************************
		     int count=0;//if delet junction
	             for(int i1=0;i1<junc_l.size();){
	                if(junc_cov[i1]<1){
	                    count=count+1;
	                    junc_l.erase(junc_l.begin()+i1);
	                    junc_r.erase(junc_r.begin()+i1);
	                    junc_cov.erase(junc_cov.begin()+i1);
			    junc_cov_plus.erase(junc_cov_plus.begin()+i1);
			    junc_cov_minus.erase(junc_cov_minus.begin()+i1);
	                }
	                else i1++;
	             }
		    vector<int> v_nu;
	            for(int a=0;a<v_Gene.size();a++){
	                if(v_Gene[a]==0) v_nu.push_back(1);
	                else if(v_Gene[a]!=0){
	                    if(v_nu.size()>0&&v_nu.size()<=MERGE_PARA){//exon之间距离<50连接
	                        for(int b=a-v_nu.size();b<a;b++){
	                            v_Gene[b]++;
	                        }
	                    }
	                    v_nu.clear();
	                }
	            }
		    //确定exon边界，非0区域
		    for(int c=0;c<v_Gene.size();c++){
	                if(c==0|| v_Gene[c-1]==0&&v_Gene[c]!=0){
	                    exon_l.push_back(gene_l+c);
	                }
	                if(c==v_Gene.size()-1|| v_Gene[c]!=0&&v_Gene[c+1]==0){
	                     exon_r.push_back(gene_l+c);
	                }
	            }
		vector<int> dele_exon_l,dele_exon_r;
            for(int i=0;i<exon_l.size();i++){
                int read_num=0;
                int nh_num=0;
                for(int j=0;j<read_beg.size();j++){
                        if( (read_beg[j]>=exon_l[i] && read_beg[j]<=exon_r[i]) || (read_fin[j]>=exon_l[i] && read_fin[j]<=exon_r[i]) ){
                            if(Read_nh[j]>1){
                                read_num++;
                                nh_num++;
                            }
                            else read_num++;
                        }
                        if(read_beg[j]>exon_r[i]) break;
                }
                if((double)nh_num/read_num>multi_map_frac){
                        dele_exon_l.push_back(exon_l[i]);
                        dele_exon_r.push_back(exon_r[i]);
                        exon_l[i]=0;
                        exon_r[i]=0;
                }
            }
            for(int i=0;i<exon_l.size();){
                if(exon_l[i]==0){exon_l.erase(exon_l.begin()+i);exon_r.erase(exon_r.begin()+i);}
                else i++;
            }
            for(int i=0;i<junc_l.size();){
                if(In_exon(junc_l[i]-1,dele_exon_l,dele_exon_r) || In_exon(junc_r[i],dele_exon_l,dele_exon_r)){
                        junc_l.erase(junc_l.begin()+i);
                        junc_r.erase(junc_r.begin()+i);
                        junc_cov.erase(junc_cov.begin()+i);
			junc_cov_plus.erase(junc_cov_plus.begin()+i);
                        junc_cov_minus.erase(junc_cov_minus.begin()+i);
                }
                else i++;
            }
		    //junction decide the exon boundry
		    if(junc_l.size()>0){//junction exists
			vector<int> junc_site_l,junc_site_r,junc_site;
	                vector<int> junc_r_sort=Sort(junc_r);
		 	for(int k1=0;k1<junc_l.size();k1++){
			    for(int k2=0;k2<exon_l.size();k2++){
			        if(junc_l[k1]>=exon_l[k2]&&junc_l[k1]<=exon_r[k2]){
				    if(junc_site_l.size()==0) {junc_site_l.push_back(junc_l[k1]);}
				    if(junc_site_l.size()>0 && junc_site_l.back() != junc_l[k1]) {junc_site_l.push_back(junc_l[k1]);}
				}
				if(junc_r_sort[k1]>exon_l[k2]&&junc_r_sort[k1]<=exon_r[k2]){
				    if(junc_site_r.size()==0) junc_site_r.push_back(junc_r_sort[k1]);
				    if(junc_site_r.size()>0 && junc_site_r.back() != junc_r_sort[k1]) {junc_site_r.push_back(junc_r_sort[k1]);}
				}
			    }
			}
			if(junc_site_l.size()>0||junc_site_r.size()>0){//partial junction exists
			    for(int k1=0;k1<junc_site_r.size();k1++){
				junc_site_l.push_back(junc_site_r[k1]);
			    }
			    junc_site=Sort(junc_site_l);
			    vector<int> exon_lt,exon_rt;
			    exon_lt=exon_l;
			    exon_rt=exon_r;
			    exon_l.clear();exon_r.clear();
			    vector<int> v_nu_exon;
			    v_nu_exon.push_back(0);
			    for(int i1=0;i1<junc_site.size();i1++){
				vector<int> v_in_site;
				for(int i2=v_nu_exon.back();i2<exon_lt.size();i2++){
		                    if(junc_site[i1]>exon_rt[i2]){
	        	                v_nu_exon.push_back(i2+1);
	                	        exon_l.push_back(exon_lt[i2]);
	                        	exon_r.push_back(exon_rt[i2]);
	                    	    }
				    if(junc_site[i1]>exon_lt[i2]&&junc_site[i1]<=exon_rt[i2]){
				  	v_nu_exon.push_back(i2+1);
					for(int i3=i1;i3<junc_site.size();i3++){
					    if(junc_site[i3]>exon_lt[i2]&& junc_site[i3]<=exon_rt[i2]){ v_in_site.push_back(junc_site[i3]);}
					    if(junc_site[i3]>exon_rt[i2]){break;}
					}
					for(int m=0;m<v_in_site.size();m++){
					    if(m==0){ exon_l.push_back(exon_lt[i2]);exon_r.push_back(v_in_site[m]-1);}
					    if(m>0&&v_in_site[m]-1-v_in_site[m-1]>=0){ exon_l.push_back(v_in_site[m-1]); exon_r.push_back(v_in_site[m]-1);}
					    if(m==v_in_site.size()-1) {exon_l.push_back(v_in_site[m]); exon_r.push_back(exon_rt[i2]);}
					}
					break;
				    }
				}
			    }
			    for(int j1=v_nu_exon.back();j1<exon_lt.size();j1++){
			 	exon_l.push_back(exon_lt[j1]);
				exon_r.push_back(exon_rt[j1]);
			    }
			}//partial junction finish
		    }//junction finish
		    //process gene
		    if(line==2){
		      	process_gene(count,exon_l,exon_r,junc_l,junc_r,seg_l,seg_r,seg_NH,exon_cov,junc_cov,v_Gene,Read,READ_LENGTH,out_name,cov_filter,strand,line,XS_plus,XS_minus,ch_note,gene_l,m_id_map);
		    }
		    if(line==1){
			//seprate a graph	
			if(XS_plus>0 && XS_minus>0){
//cout<<XS_plus<<" "<<XS_minus<<endl;
				vector<int>junc_plus_l,junc_plus_r,junc_minus_l,junc_minus_r;
				vector<int> exon_plus_l,exon_plus_r,exon_minus_l,exon_minus_r;
				vector<int> same_false_junc;
				vector<double> junc_cov_p,junc_cov_m;
				Graph_division graph_division;
				graph_division.division(exon_l,exon_r,junc_l,junc_r,junc_cov,junc_cov_plus,junc_cov_minus);
				junc_plus_l=graph_division.get_junc_plus_l();
				junc_plus_r=graph_division.get_junc_plus_r();
				junc_minus_l=graph_division.get_junc_minus_l();
				junc_minus_r=graph_division.get_junc_minus_r();
				exon_plus_l=graph_division.get_exon_plus_l();
                                exon_plus_r=graph_division.get_exon_plus_r();
                                exon_minus_l=graph_division.get_exon_minus_l();
                                exon_minus_r=graph_division.get_exon_minus_r();
				same_false_junc=graph_division.get_same_false_junc();
				junc_cov_p=graph_division.get_junc_cov_plus();
				junc_cov_m=graph_division.get_junc_cov_minus();
				double rate_1=(double)(XS_plus/(XS_plus+XS_minus));
				double rate_2=(double)(XS_minus/(XS_plus+XS_minus));
				XS_plus=1;XS_minus=0;count=0;
//cout<<"here"<<endl;
				process_unstrand_gene(count,exon_plus_l,exon_plus_r,junc_plus_l,junc_plus_r,seg_l,seg_r,seg_NH,exon_cov,junc_cov_p,v_Gene,Read,READ_LENGTH,out_name,cov_filter,strand,line,XS_plus,XS_minus,ch_note,gene_l,m_id_map,rate_1,same_false_junc);
				XS_plus=0;XS_minus=1;
				process_unstrand_gene(count,exon_minus_l,exon_minus_r,junc_minus_l,junc_minus_r,seg_l,seg_r,seg_NH,exon_cov,junc_cov_m,v_Gene,Read,READ_LENGTH,out_name,cov_filter,strand,line,XS_plus,XS_minus,ch_note,gene_l,m_id_map,rate_2,same_false_junc);
				
			}
			else process_gene(count,exon_l,exon_r,junc_l,junc_r,seg_l,seg_r,seg_NH,exon_cov,junc_cov,v_Gene,Read,READ_LENGTH,out_name,cov_filter,strand,line,XS_plus,XS_minus,ch_note,gene_l,m_id_map);
		    }
		    //
		    //
		    //
		}//if gene_length>200 finish!
		//initial next gene!
		    m_id_map.clear();//Read.clear();
		    XS_plus=0;XS_minus=0;
		    read_beg.clear();read_fin.clear();Read_nh.clear();
	            read_beg.push_back(read_start);read_fin.push_back(read_last_site);Read_nh.push_back(read_NH);
			
		    exon_l.clear();exon_r.clear();junc_l.clear();junc_r.clear();junc_cov.clear(),seg_l.clear();seg_r.clear();exon_cov.clear();junc_cov_plus.clear();junc_cov_minus.clear();
		    seg_NH.clear();
		    v_Gene.clear();
		    gene_l=read_start;
		    max_map=read_last_site;
		    for(int i=0;i<=max_map-gene_l;i++) v_Gene.push_back(0);
	            for(int j=0;j<read_seg_l.size();j++){
	                for(int k=read_seg_l[j]-gene_l;k<=read_seg_r[j]-gene_l;k++){
	                    double d=1.00000/(read_NH*read_NH);
	                    v_Gene[k]=v_Gene[k]+d;
	                }
			seg_l.push_back(read_seg_l[j]);
			seg_r.push_back(read_seg_r[j]);
			seg_NH.push_back(read_NH*read_NH);
	            }
		    for(int i=0;i<read_junc_l.size();i++){
			junc_l.push_back(read_junc_l[i]);
			junc_r.push_back(read_junc_r[i]);
			double d=1.00000/(read_NH*read_NH);
			junc_cov.push_back(d);
			if(xs_flag==1){junc_cov_plus.push_back(d);junc_cov_minus.push_back(0);}
			else {junc_cov_plus.push_back(0);junc_cov_minus.push_back(d);}
		    }
		    if(read_junc_l.size()>0){
	              for(int i=0;i<read_seg_l.size()-1;i++){
	                read_temp.push_back(read_seg_l[i]);read_temp.push_back(read_seg_r[i]);
	                read_temp.push_back(read_junc_l[i]);read_temp.push_back(read_junc_r[i]);
	              }
	    	    }
		    if(read_NH==1 && read_pair=="="){//edge_node_pair支持
	                vector<string> start_map;
	                stringstream start_to_string;//start转成string格式
	                start_to_string<<read_start;
	                string start;
	                start_to_string>>start;
	                start_map.push_back(start);
	                start_map.push_back(read_map);
	                m_id_map.insert(pair<string,vector<string> > (read_id,start_map));
	            }   
	
		    
		}//else current read in next gene finish
	        ch_note.erase(ch_note.begin());
	        ch_note.push_back(read_ch);
	    }//if (seg.length>0) 
          }//if(Has_chr(read_ch)) finishi
	    
       }//while (getline) finish
    }//while getline(i,input) finish
}
