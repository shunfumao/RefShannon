#include<string>
using namespace std;
bool Has_junc(string s){
    string::size_type idx=s.find("N");
    if(idx!=string::npos) {return 1;}
    else return 0;
}
