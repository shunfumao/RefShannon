#include<iostream>
#include<vector>
using namespace std;
vector<int> insert(vector<int> v,int k,int in){
    int num=v.back();
    v.push_back(num);
    for(int i=v.size()-1;i>k-1;i--){
	v[i]=v[i-1];
    }
    v[k]=in;
    return v;
}
vector<double> insert_d(vector<double> v,int k,double in){
    double num=v.back();
    v.push_back(num);
    for(int i=v.size()-1;i>k-1;i--){
        v[i]=v[i-1];
    }
    v[k]=in;
    return v;
}

//**********************************************************2015/10/31
class Insert_junction{
	private: vector<int> junc_li,junc_ri; vector<double> junc_covi;
	public:  
		void insert_junc(vector<int> junc_l,vector<int> junc_r,vector<double> junc_cov,int new_junc_l,int new_junc_r,double new_junc_cov);
		vector<int> get_junc_l();
		vector<int> get_junc_r();
		vector<double> get_junc_cov();
};
void Insert_junction::insert_junc(vector<int> junc_l,vector<int> junc_r,vector<double> junc_cov,int new_junc_l,int new_junc_r,double new_junc_cov){
    if( new_junc_l==junc_l.back() && new_junc_r==junc_r.back()){
	junc_cov.back()=junc_cov.back()+new_junc_cov;
    }
    if(new_junc_l>junc_l.back() || (new_junc_l==junc_l.back() && new_junc_r>junc_r.back())){
	junc_l.push_back(new_junc_l);
 	junc_r.push_back(new_junc_r);
	junc_cov.push_back(new_junc_cov);
    }
    if(new_junc_l<junc_l.back() || (new_junc_l==junc_l.back() && new_junc_r<junc_r.back())){
	for(int k=junc_l.size()-1;k>=0;k--){
	    if(new_junc_l==junc_l[k] && new_junc_r==junc_r[k]){
		junc_cov[k]=junc_cov[k]+new_junc_cov;
		break;
	    }
	    if(new_junc_l>junc_l[k] || (new_junc_l==junc_l[k] && new_junc_r>junc_r[k])){
		junc_l=insert(junc_l,k+1,new_junc_l);
		junc_r=insert(junc_r,k+1,new_junc_r);
		junc_cov=insert_d(junc_cov,k+1,new_junc_cov);
		break;
	    }
	    if(k==0){
		vector<int> junc_lt,junc_rt;vector<double>junc_covt;
		junc_lt=junc_l;junc_rt=junc_r;junc_covt=junc_cov;
		junc_l.clear();junc_r.clear();junc_cov.clear();
		junc_l.push_back(new_junc_l);
		junc_r.push_back(new_junc_r);
		junc_cov.push_back(new_junc_cov);
		for(int m=0;m<junc_lt.size();m++){
		    junc_l.push_back(junc_lt[m]);
                    junc_r.push_back(junc_rt[m]);
                    junc_cov.push_back(junc_covt[m]);
		}
	    }
	}
    }
    junc_li=junc_l;junc_ri=junc_r;junc_covi=junc_cov;
}
vector<int> Insert_junction::get_junc_l(){return junc_li;}
vector<int> Insert_junction::get_junc_r(){return junc_ri;}
vector<double> Insert_junction::get_junc_cov(){return junc_covi;}
