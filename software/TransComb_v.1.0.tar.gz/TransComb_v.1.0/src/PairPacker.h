#ifndef PAIRPACKER_H
#define PAIRPACKER_H

// PairPacker.h

#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<vector>
#include<stdlib.h>
#include<algorithm>
#include<cstring>
using namespace std;

class PairPacker
{
	private:
	vector<vector<int> > Path_cover;
	vector<double> Level;
	vector<string> Node_seq_1;
	vector<int> Node_seq_2,Node_seq_3;
        vector<double> Node_seq_4;
	int Graph_num;
	int Trans_id;
	double Min_cov;
	vector<int> Single_nodes;// from junction_graph.Single_nodes
	char * Output_path;
	int Path_length;
	int Strand;
	double Multi;
	public:
	PairPacker(vector<vector<int> > path_cover,vector<double> level,vector<string> node_seq_1,vector<int> node_seq_2,vector<int> node_seq_3,vector<double> node_seq_4,int graph_num,int trans_id,double min_cov,vector<int> single_nodes,char * output_path,int path_length,int strand,double multi);
	~PairPacker();
	void PairPacker_Output();
	int Curr_id;
};
PairPacker::PairPacker(vector<vector<int> > path_cover,vector<double> level,vector<string> node_seq_1,vector<int> node_seq_2,vector<int> node_seq_3,vector<double> node_seq_4,int graph_num,int trans_id,double min_cov,vector<int> single_nodes,char * output_path,int path_length,int strand,double multi)
{
	Path_cover=path_cover;
	Level=level;
	Node_seq_1=node_seq_1;
	Node_seq_2=node_seq_2;
	Node_seq_3=node_seq_3;
	Node_seq_4=node_seq_4;
	Graph_num=graph_num;
	Trans_id=trans_id;
	Min_cov=min_cov;
	Single_nodes=single_nodes;
	Output_path=output_path;
	Path_length=path_length;
	Strand=strand;
	Multi=multi;
	return;
}
PairPacker::~PairPacker()
{
	return;
}
void PairPacker::PairPacker_Output()
{
	Curr_id=Trans_id;
	int i,j,k,t,strand_id;
	string Symble=".+-";
	if (Strand==0)
	{
		strand_id=0;
	}
	else if (Strand==1)
	{
		strand_id=1;
	}
	else
	{
		strand_id=2;
	}
	ofstream file;
        file.open(Output_path,ios_base::app);
	for (i=0;i<Path_cover.size();i++)
        {
		k=0;
                for (j=0;j<Path_cover[i].size();j++)
                {
                        k=k+Node_seq_3[Path_cover[i][j]]-Node_seq_2[Path_cover[i][j]]+1;
                }
		if (k>=Path_length && Level[i]>=Min_cov)
		{
			file<<Node_seq_1[Path_cover[i][0]]<<"	"<<"PairPacker"<<"	"<<"transcript"<<"	"<<Node_seq_2[Path_cover[i][0]]<<"	"<<Node_seq_3[Path_cover[i][Path_cover[i].size()-1]]<<"	"<<1000<<"	"<<Symble[strand_id]<<"	.	gene_id "<<"\""<<"PAIRP."<<Graph_num<<"\""<<"; "<<"transcript_id "<<"\""<<"PAIRP."<<Graph_num<<"."<<Curr_id<<"\""<<"; "<<"coverage "<<Level[i]<<"; "<<"FPKM "<<Level[i]*Multi<<";"<<endl;
			for (j=0;j<Path_cover[i].size()-1;j++)
               		{
				file<<Node_seq_1[Path_cover[i][j]]<<"	"<<"PairPacker"<<"	"<<"exon"<<"	"<<Node_seq_2[Path_cover[i][j]]<<"	"<<Node_seq_3[Path_cover[i][j]]<<"	"<<1000<<"	"<<Symble[strand_id]<<"	.	gene_id "<<"\""<<"PAIRP."<<Graph_num<<"\""<<"; "<<"transcript_id "<<"\""<<"PAIRP."<<Graph_num<<"."<<Curr_id<<"\""<<"; "<<"exon_number "<<"\""<<j+1<<"\""<<";"<<endl;
			}
			file<<Node_seq_1[Path_cover[i][Path_cover[i].size()-1]]<<"	"<<"PairPacker"<<"	"<<"exon"<<"	"<<Node_seq_2[Path_cover[i][Path_cover[i].size()-1]]<<"	"<<Node_seq_3[Path_cover[i][Path_cover[i].size()-1]]<<"	"<<1000<<"	"<<Symble[strand_id]<<"	.	gene_id "<<"\""<<"PAIRP."<<Graph_num<<"\""<<"; "<<"transcript_id "<<"\""<<"PAIRP."<<Graph_num<<"."<<Curr_id<<"\""<<"; "<<"exon_number "<<"\""<<j+1<<"\""<<";"<<endl;
			Curr_id++;
		}
	}
	for (i=0;i<Single_nodes.size();i++)
        {
		if (Node_seq_3[Single_nodes[i]]-Node_seq_2[Single_nodes[i]]+1>=Path_length && Node_seq_4[Single_nodes[i]]>=3.0 && Node_seq_4[Single_nodes[i]]>=Min_cov)
		{
			file<<Node_seq_1[Single_nodes[i]]<<"	"<<"PairPacker"<<"	"<<"transcript"<<"	"<<Node_seq_2[Single_nodes[i]]<<"	"<<Node_seq_3[Single_nodes[i]]<<"	"<<1000<<"	"<<Symble[strand_id]<<"	.	gene_id "<<"\""<<"PAIRP."<<Graph_num<<"\""<<"; "<<"transcript_id "<<"\""<<"PAIRP."<<Graph_num<<"."<<Curr_id<<"\""<<"; "<<"coverage "<<Node_seq_4[Single_nodes[i]]<<"; "<<"FPKM "<<Node_seq_4[Single_nodes[i]]*Multi<<";"<<endl;
                        file<<Node_seq_1[Single_nodes[i]]<<"	"<<"PairPacker"<<"	"<<"exon"<<"	"<<Node_seq_2[Single_nodes[i]]<<"	"<<Node_seq_3[Single_nodes[i]]<<"	"<<1000<<"	"<<Symble[strand_id]<<"	.	gene_id "<<"\""<<"PAIRP."<<Graph_num<<"\""<<"; "<<"transcript_id "<<"\""<<"PAIRP."<<Graph_num<<"."<<Curr_id<<"\""<<"; "<<"exon_number "<<"\""<<1<<"\""<<";"<<endl;
			Curr_id++;
		}
	}
	file.close();
	return;
}// end of PairPacker_Output

#endif


