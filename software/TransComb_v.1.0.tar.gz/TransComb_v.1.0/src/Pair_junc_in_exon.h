#include<vector>
using namespace std;
//***************************************************************** 2015/10/31
//which node a read in
int Read_in_exon(vector<int> exon_l,vector<int> exon_r,int read_site){
    for(int i=0;i<exon_l.size();i++){
	if(read_site>=exon_l[i] && read_site <= exon_r[i]) return i; 
    }
    return -1;
}
//if two exon has junction
bool Has_two_exon_junction(vector<int> exon_l,vector<int> exon_r,vector<int>junc_l,vector<int>junc_r,int exon_num1,int exon_num2){
    int exon1_r=exon_r[exon_num1];
    int exon2_l=exon_l[exon_num2];
    for(int i=0;i<junc_l.size();i++){
	if(exon1_r+1==junc_l[i] && exon2_l==junc_r[i]) return true;
    }
    return false;
}

//***************************************************************** 2015/10/31
//***************************************************************** 2015/11/14
int juncl_in_exon(int junc_l,vector<int> exon_l,vector<int> exon_r){
    int exon_num;
    for(int i=0;i<exon_l.size();i++){
	if(exon_r[i]==junc_l-1) exon_num=i;
    }
    return exon_num;
}
int juncr_in_exon(int junc_r,vector<int> exon_l,vector<int> exon_r){
    int exon_num;
    for(int i=0;i<exon_l.size();i++){
	if(exon_l[i]==junc_r) exon_num=i;
    }
    return exon_num;
}
//class return exon out and in junction
class Exon_edge{
	private: vector<int> In_junc_l,In_junc_r,Out_junc_l,Out_junc_r;
		 vector<double> In_junc_cov,Out_junc_cov;
	public:  void find_exon_edge(int exon_num,vector<int> exon_l,vector<int> exon_r,vector<int>junc_l,vector<int>junc_r,vector<double> junc_cov,vector<int>false_junc,vector<double> false_junc_cov);
		 vector<int> get_In_junc_l();
		 vector<int> get_In_junc_r();
		 vector<double> get_In_junc_cov();
		 vector<int> get_Out_junc_l();
		 vector<int> get_Out_junc_r();
	 	 vector<double> get_Out_junc_cov();
};
void Exon_edge::find_exon_edge(int exon_num,vector<int> exon_l,vector<int> exon_r,vector<int>junc_l,vector<int>junc_r,vector<double> junc_cov,vector<int>false_junc,vector<double> false_junc_cov){
	int exon_l_cur=exon_l[exon_num];
	int exon_r_cur=exon_r[exon_num];
	for(int i=0;i<junc_l.size();i++){
	    	if(junc_l[i]-1==exon_r_cur){
			Out_junc_l.push_back(junc_l[i]);
			Out_junc_r.push_back(junc_r[i]);
			Out_junc_cov.push_back(junc_cov[i]);
		}
		if(junc_r[i]==exon_l_cur){
			In_junc_l.push_back(junc_l[i]);
			In_junc_r.push_back(junc_r[i]);
			In_junc_cov.push_back(junc_cov[i]);
		}
	}
	for(int i=0;i<false_junc.size();i++){
		if(false_junc[i]==exon_r_cur && false_junc_cov[i]>=2){
			Out_junc_l.push_back(false_junc[i]);
			Out_junc_r.push_back(false_junc[i]+1);
			Out_junc_cov.push_back(false_junc_cov[i]);
		}
		if(false_junc[i]+1==exon_l_cur && false_junc_cov[i]>=2){
			In_junc_l.push_back(false_junc[i]);
			In_junc_r.push_back(false_junc[i]+1);
			In_junc_cov.push_back(false_junc_cov[i]);
		}
	}
}
vector<int>  Exon_edge::get_In_junc_l(){return In_junc_l;}
vector<int>  Exon_edge::get_In_junc_r(){return In_junc_r;}
vector<double> Exon_edge::get_In_junc_cov(){return In_junc_cov;}
vector<int>  Exon_edge::get_Out_junc_l(){return Out_junc_l;}
vector<int>  Exon_edge::get_Out_junc_r(){return Out_junc_r;}
vector<double> Exon_edge::get_Out_junc_cov(){return Out_junc_cov;}
//*****************************************************************2015/11/14 bottom
vector<int> Pair_left_juncr_in_exon(vector<int> junc_r,vector<int> exon_l,vector<int> exon_r){
    vector<int>exon_num;
for(int j=0;j<junc_r.size();j++){
    for(int i=0;i<exon_l.size();i++){
	if(junc_r[j]==exon_l[i]) exon_num.push_back(i);
    }
}
    return exon_num;
}
vector<int> Pair_right_juncl_in_exon(vector<int> junc_l,vector<int>exon_l,vector<int> exon_r){
    vector<int>exon_num;
for(int j=0;j<junc_l.size();j++){
    for(int i=0;i<exon_r.size();i++){
	if(junc_l[j]-1==exon_r[i]) exon_num.push_back(i);
    }
}
    return exon_num;
}
bool exon_multi_in_out(vector<int>junc_l,vector<int> junc_r,vector<int>exon_l,vector<int>exon_r,vector<int>exon_num){
    if(junc_l.size()<=3) return false;
    vector<int> exon_l_t,exon_r_t;
    for(int i=0;i<exon_num.size();i++){
	exon_l_t.push_back(exon_l[exon_num[i]]);
	exon_r_t.push_back(exon_r[exon_num[i]]);
    }
    int max_in=0;int max_out=0;
for(int j=0;j<exon_l_t.size();j++){
    int count_in=0;int count_out=0;
    for(int i=0;i<junc_l.size();i++){
	if(junc_r[i]==exon_l_t[j]) count_in++;
	if(junc_l[i]-1==exon_r_t[j]) count_out++;
    }

    if(max_in<count_in) max_in=count_in;
    if(max_out<count_out)max_out=count_out;

}
//cout<<max_in<<" "<<max_out<<"--"<<exon_l_t.back()<<endl;
    if(max_in>=2&&max_out>=2) return true;
    else return false;
   
}
