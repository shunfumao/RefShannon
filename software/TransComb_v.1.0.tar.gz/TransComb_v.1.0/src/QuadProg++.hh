#ifndef _QUADPROGPP
#define _QUADPROGPP
#ifndef MATRIX_DIM
#define MATRIX_DIM 500
#endif

double solve_quadprog(double G[][MATRIX_DIM], double g0[], int n, 
                      double CE[][MATRIX_DIM], double ce0[], int p, 
                      double CI[][MATRIX_DIM], double ci0[], int m,
                      double x[]);
#endif // #define _QUADPROGPP
