#include<vector>
using namespace std;
vector<int> Sort(vector<int>v){
        for(int i=0;i<v.size()-1;i++){
            int index=i;
//cout<<i<<endl;
            for(int j=i+1;j<v.size();j++){
                if(v[j]<v[index]) {index=j;}
		/*else{
		    if(v[j]==v[index]) v.erase(v.begin()+j);
		    else j++;
		}*/
            }
            if(index!=i){
                int a=v[i];v[i]=v[index];v[index]=a;
            }
        }
        return v;
}
