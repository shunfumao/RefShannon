#include"expression_level.h"
#include"Sort.h"
#include"Trim.h"
#include"Function.h"
#include"get_junction_graph.h"
#include"junction_paths_new.h"
#include"recover_paths.h"
#include"PairPacker.h"
	
using namespace std;

	extern string FILTER;

	extern int Path_length;

	extern int trim;

	extern float SEED_Filter;
	
	extern double multi;
/*
	string Anchor_Length; int anchor_length;
	string Multi_Map_Frac; float multi_map_frac;
	double Mul_RATE=0.01;
	double SEP_EXON_RATE=0.25;
	int READ_LENGTH=0;
*/
	extern int rg_index;
	extern int trans_id;
	//double SEED_Filter=0;
	string base_name()
	{
	    stringstream idx ;
	    idx << "comp" << rg_index ;
	    rg_index++;
	    trans_id=1;
	    return idx.str();
	}
	string describe_graph(int gene_l,vector<int> junc_l,vector<int>junc_r,vector<double>junc_cov,vector<int> exon_l,vector<int> exon_r,vector<double> v_exon_cov,vector<int> pair_edge,vector<int> pair_node,string ch,vector<int>false_junc,vector<double>false_junc_cov,vector<double>v_Gene,map<vector<int>,double> Read,int READ_LENGTH,char * out_name,string cov_filter,int strand,int line,int XS_plus,int XS_minus)
	{
//cout<<strand<<"*"<<endl;

		int sum=0;
		for(int i=0;i<false_junc.size();i++){
		    if(false_junc_cov[i]>=2) sum++;
		}
		//cout<<rg_index-1<<" "<<sum<<endl;
		//cout<<"exon number"<<exon_l.size()<<endl;
		vector<int> pair_node_l,pair_node_r;
		for(int i=0;i<pair_node.size();i++){
		    pair_node_l.push_back(exon_l[pair_node[i]]);
		    pair_node_r.push_back(exon_r[pair_node[i]]);
		}
	//****************************************************************** trim
	
	if(trim==1){
		vector<int> exon_l_p,exon_r_p;
	        exon_l_p=exon_l;exon_r_p=exon_r;
	if(exon_l_p.size()>1){
	        for(int i=0;i<exon_l_p.size();i++){
	                if(!is_in(exon_l_p[i],junc_r)&&!is_in(exon_l_p[i]-1,false_junc)){
	                    int l=exon_r_p[i]-exon_l_p[i]+1;
	                    int site=exon_l_p[i]-gene_l;
	                    vector<int> seg_node=find_trims(gene_l,exon_l_p[i],exon_r_p[i],v_Gene);
	                    if(seg_node.size()>0 && seg_node[0]!=0){
	                        exon_l_p[i]=seg_node[0];
	                    }
	                    double cov=0.00000;
	                    int l_new=exon_r_p[i]-exon_l_p[i]+1;
	                    for(int j=exon_l_p[i]-gene_l;j<=l+site-1;j++) cov=cov+v_Gene[j];
	                    v_exon_cov[i]=cov/l_new;
	                }
	        }
	        for(int i=0;i<exon_l_p.size();i++){
	            if(!is_in(exon_r_p[i]+1,junc_l)&&!is_in(exon_r_p[i],false_junc)){
	                    int l=exon_r_p[i]-exon_l_p[i]+1;
	                    int site=exon_l_p[i]-gene_l;
	                    vector<int> seg_node=find_trims(gene_l,exon_l_p[i],exon_r_p[i],v_Gene);
	                    if(seg_node.size()>0 && seg_node[1]!=0){
	                        exon_r_p[i]=seg_node[1];
	                    }
	                    double cov=0.00000;
	                    int l_new=exon_r_p[i]-exon_l_p[i]+1;
	                    for(int j=site;j<=exon_r_p[i]-gene_l;j++) cov=cov+v_Gene[j];
	                    v_exon_cov[i]=cov/l_new;
	            }
	        }
	        exon_l=exon_l_p;exon_r=exon_r_p;
	}
	}
	//************************************************************************************************************* trim
		float Min_cov=atof(FILTER.c_str());
//		float Min_cov=atof(cov_filter.c_str());
		vector<string> vec_edges,vec_pairs,Node_seq_1;
		vector<int>Node_seq_2,Node_seq_3;
		vector<double>Node_seq_4;
	//cout<<"f"<<endl;
		for(int i=0;i<junc_l.size();i++){
			string edge;
			stringstream ss;
			for(int j=0;j<exon_l.size();j++){
				if(junc_l[i]-1==exon_r[j]) {ss<<j<<"->";}
				if(junc_r[i]==exon_l[j])  {ss<<j<<":"<<junc_cov[i]<<";";}
			}
			ss>>edge;
			//cout<<edge;
			vec_edges.push_back(edge);
		}
		//cout<<vec_edges.size()<<endl;
	//for(int i=0;i<vec_edges.size();i++)cout<<vec_edges[i]<<endl;
		for(int i=0;i<pair_edge.size();i++){
			int node=find(pair_node_l[i],exon_l);
			string pair;
			stringstream ss;
			if(node!=-1){
				ss<<pair_edge[i]<<"->"<<node<<"->"<<1;
				ss>>pair;
				vec_pairs.push_back(pair);
			}
		}
	//for(int i=0;i<vec_pairs.size();i++)cout<<vec_pairs[i]<<endl;
		for(int i=0;i<exon_l.size();i++){
			Node_seq_1.push_back(ch);
			Node_seq_2.push_back(exon_l[i]);
			Node_seq_3.push_back(exon_r[i]);
			Node_seq_4.push_back(v_exon_cov[i]);
		}
	//for(int i=0;i<Node_seq_1.size();i++)cout<<Node_seq_1[i]<<" "<<Node_seq_2[i]<<" "<<Node_seq_3[i]<<" "<<Node_seq_4[i]<<endl;
		int Graph_num=rg_index-1;
	
		Get_Junction_Graph junction_graph(vec_edges,vec_pairs); //here need two vector: vec_edges,vec_pairs.
	        junction_graph.Construct_Junction_Graph();
	        Get_Junction_Paths get_junction_paths(junction_graph.Edges_left,junction_graph.Edges_right,junction_graph.Weights,junction_graph.DAG_weights,junction_graph.Cons_left,junction_graph.Cons_right,junction_graph.S,junction_graph.T,junction_graph.Single_nodes,junction_graph.max_node_num,SEED_Filter);
	        get_junction_paths.Search_Junction_Paths();
	        Recover_Junction_Paths recover_junction_paths(junction_graph.DAG_left,junction_graph.DAG_right,get_junction_paths.Junction_Path_cover,junction_graph.max_node_num);
	        recover_junction_paths.Get_Path_cover();
	        Express_Level express_level(junction_graph.DAG_left,junction_graph.DAG_right,junction_graph.DAG_weights,get_junction_paths.Seeds_num,recover_junction_paths.Path_Cover);
	        express_level.Compute_Express_Level();
	    if(line==2&&strand==1)
	        {
			PairPacker pairpacker(recover_junction_paths.Path_Cover,express_level.Level,Node_seq_1,Node_seq_2,Node_seq_3,Node_seq_4,Graph_num,trans_id,Min_cov,junction_graph.Single_nodes,out_name,Path_length,1,multi); // here need: Node_seq_1,Node_seq_2,Node_seq_3,Node_seq_4,Graph_num,Output_path.
			pairpacker.PairPacker_Output();
			trans_id=pairpacker.Curr_id;
		}
	    if(line==2&&strand==2) 
	    {
		PairPacker pairpacker(recover_junction_paths.Path_Cover,express_level.Level,Node_seq_1,Node_seq_2,Node_seq_3,Node_seq_4,Graph_num,trans_id,Min_cov,junction_graph.Single_nodes,out_name,Path_length,2,multi);
	        pairpacker.PairPacker_Output();
		trans_id=pairpacker.Curr_id;
	    }

	    if(line==1){
		if(XS_plus>=XS_minus && XS_plus!=0){
		    if(XS_minus<100){
			PairPacker pairpacker(recover_junction_paths.Path_Cover,express_level.Level,Node_seq_1,Node_seq_2,Node_seq_3,Node_seq_4,Graph_num,trans_id,Min_cov,junction_graph.Single_nodes,out_name,Path_length,1,multi);
			pairpacker.PairPacker_Output();
			trans_id=pairpacker.Curr_id;
		    }
		    else{
			PairPacker pairpacker(recover_junction_paths.Path_Cover,express_level.Level,Node_seq_1,Node_seq_2,Node_seq_3,Node_seq_4,Graph_num,trans_id,Min_cov,junction_graph.Single_nodes,out_name,Path_length,0,multi);
                        pairpacker.PairPacker_Output();
			trans_id=pairpacker.Curr_id;
		    }
		}
		if(XS_plus<XS_minus && XS_minus!=0){
		    if(XS_plus<100){
			PairPacker pairpacker(recover_junction_paths.Path_Cover,express_level.Level,Node_seq_1,Node_seq_2,Node_seq_3,Node_seq_4,Graph_num,trans_id,Min_cov,junction_graph.Single_nodes,out_name,Path_length,2,multi);
			pairpacker.PairPacker_Output();
			trans_id=pairpacker.Curr_id;
		    }
		    else{
			PairPacker pairpacker(recover_junction_paths.Path_Cover,express_level.Level,Node_seq_1,Node_seq_2,Node_seq_3,Node_seq_4,Graph_num,trans_id,Min_cov,junction_graph.Single_nodes,out_name,Path_length,0,multi);
                        pairpacker.PairPacker_Output();
			trans_id=pairpacker.Curr_id;
		    }
		}
		if(XS_plus==0&&XS_minus==0)
		{
			PairPacker pairpacker(recover_junction_paths.Path_Cover,express_level.Level,Node_seq_1,Node_seq_2,Node_seq_3,Node_seq_4,Graph_num,trans_id,Min_cov,junction_graph.Single_nodes,out_name,Path_length,0,multi);
			pairpacker.PairPacker_Output();
			trans_id=pairpacker.Curr_id;
		}

	    }
	
/*
	    if(line==1){
		PairPacker pairpacker(recover_junction_paths.Path_Cover,express_level.Level,Node_seq_1,Node_seq_2,Node_seq_3,Node_seq_4,Graph_num,Min_cov,junction_graph.Single_nodes,out_name,Path_length,1);
		pairpacker.PairPacker_Output();
	    }
*/
	
	
	        stringstream graph;
	        return graph.str();
	
	}
	bool save_debug(const string& filename,int gene_l,vector<int> junc_l,vector<int>junc_r,vector<double>junc_cov,vector<int> exon_l,vector<int> exon_r,vector<double> v_exon_cov,vector<int>pair_edge,vector<int>pair_node,string ch,vector<int>false_junc,vector<double>false_junc_cov,vector<double>v_Gene,map<vector<int>, double> Read,int READ_LENGTH,char * out_name,string cov_filter,int strand,int line,int XS_plus,int XS_minus)
	{
	    ofstream ofs(filename.c_str());
	    const string graph = describe_graph(gene_l,junc_l,junc_r,junc_cov,exon_l,exon_r,v_exon_cov,pair_edge,pair_node,ch,false_junc,false_junc_cov,v_Gene,Read,READ_LENGTH,out_name,cov_filter,strand,line,XS_plus,XS_minus); //a readable format
	    ofs << graph;
	
	    return true;
	}
	
