#include<iostream>
#include<algorithm>
#include<map>
#include<vector>
#include"Has_junc.h"
//#include"Find_junc_last_map.h"
#include"read_node.h"
#include"Pair_junc_in_exon.h"
using namespace std;
class Edge_Node_Pair{
    private: vector<int> Edge;vector<int>Node;
    public:
     	     void Find_edge_node(vector<int>exon_l,vector<int>exon_r,vector<int> junc_l,vector<int> junc_r,multimap<string,vector<string> > m_id_map);
	     vector<int> get_Edge();
             vector<int> get_Node();
};
void  Edge_Node_Pair:: Find_edge_node(vector<int>exon_l,vector<int>exon_r,vector<int> junc_l,vector<int> junc_r,multimap<string,vector<string> > m_id_map){
    typedef multimap<string,vector<string> >::iterator iter;
    multimap <int,int> m_edge_node;
    typedef multimap<int,int>:: iterator iter_i;
    for(iter i=m_id_map.begin();i!=m_id_map.end();i++){
	//cout<<i->first<<endl;
    }
    for(iter i=m_id_map.begin();i!=m_id_map.end();){
	vector<int> pair_junc_l,pair_junc_r;
	vector<int> edge_cur,node_cur;
	int pair_node=-1;//one pair has no junction, which node it is in 2015/10/31
	string read_id=i->first;
	int num=m_id_map.count(read_id);
	if(num==2){//pair两端都在当前基因内
	    iter lower=m_id_map.lower_bound(read_id);//返回当前键值的第一个位置
	    i=m_id_map.upper_bound(read_id);//返回当前键值对应的下一个键值的第一个位置
	    vector<string> left_start_map,right_start_map;
	    left_start_map=lower->second;
	    lower++;
            iter last=lower;
	    right_start_map=last->second;
    	    int left_start,right_start;
	    string left_map,right_map,s;
	    s=left_start_map[0];
 	    left_start=atoi(s.c_str());
	    left_map=left_start_map.back();
//cout<<left_start<<" "<<left_map<<endl;
	    s=right_start_map[0];
	    right_start=atoi(s.c_str());
            right_map=right_start_map.back();
//cout<<right_start<<" "<<right_map<<endl<<endl;;
	    int Has_junc_l=Has_junc(left_map);
            int Has_junc_r=Has_junc(right_map);
	    if(Has_junc_l!=0 && Has_junc_r!=0){
		//find junction of left pair
 	         vector<int> L_pair_junc_l,L_pair_junc_r,L_exon_num;
	         Find_junc L_find_junc;
	         L_find_junc.find_junc(left_start,left_map);
  	         L_pair_junc_l=L_find_junc.get_read_junc_l();
                 L_pair_junc_r=L_find_junc.get_read_junc_r();
		 vector<int> L_pair_junc_r_last;
		 L_pair_junc_r_last.push_back(L_pair_junc_r.back());
		 L_exon_num=Pair_left_juncr_in_exon(L_pair_junc_r_last,exon_l,exon_r);
		//find junction of right pair
                 vector<int> R_pair_junc_l,R_pair_junc_r,R_exon_num;
                 Find_junc R_find_junc;
                 R_find_junc.find_junc(right_start,right_map);
                 R_pair_junc_l=R_find_junc.get_read_junc_l();
                 R_pair_junc_r=R_find_junc.get_read_junc_r();
		 vector<int> R_pair_junc_l_first;
		 R_pair_junc_l_first.push_back(R_pair_junc_l[0]);
		 R_exon_num=Pair_right_juncl_in_exon( R_pair_junc_l_first,exon_l,exon_r);
		 bool L_exon_multi_in_out=exon_multi_in_out(junc_l,junc_r,exon_l,exon_r,L_exon_num);
		 bool R_exon_multi_in_out=exon_multi_in_out(junc_l,junc_r,exon_l,exon_r,R_exon_num);
		 if(L_exon_multi_in_out && R_exon_multi_in_out){
		    for(int m=0;m<L_pair_junc_l.size();m++)
                     {
                          pair_junc_l.push_back(L_pair_junc_l[m]);
                          pair_junc_r.push_back(L_pair_junc_r[m]);
                     }

                     for(int m=0;m<R_pair_junc_l.size();m++)
                     {
                          pair_junc_l.push_back(R_pair_junc_l[m]);
                          pair_junc_r.push_back(R_pair_junc_r[m]);
                     }
		 }
		 else{
		     if(L_pair_junc_l.size()>=2){
		     	vector<int> mid_junc_l;
			mid_junc_l.push_back(L_pair_junc_l[1]);
		    	vector<int> mid_exon_num=Pair_right_juncl_in_exon(mid_junc_l,exon_l,exon_r);
		     	bool mid_exon_multi_in_out(exon_multi_in_out(junc_l,junc_r,exon_l,exon_r,mid_exon_num));
			if(mid_exon_multi_in_out){
  		    	    for(int m=0;m<L_pair_junc_l.size();m++){
			        pair_junc_l.push_back(L_pair_junc_l[m]);
			        pair_junc_r.push_back(L_pair_junc_r[m]);
			    }
			}
		     }
		     if(R_pair_junc_l.size()>=2){
			vector<int> mid_junc_l;
                        mid_junc_l.push_back(R_pair_junc_l[1]);
			vector<int> mid_exon_num=Pair_right_juncl_in_exon(mid_junc_l,exon_l,exon_r);
                        bool mid_exon_multi_in_out(exon_multi_in_out(junc_l,junc_r,exon_l,exon_r,mid_exon_num));
			if(mid_exon_multi_in_out){
			    for(int m=0;m<R_pair_junc_l.size();m++){
			         pair_junc_l.push_back(R_pair_junc_l[m]);
			   	 pair_junc_r.push_back(R_pair_junc_r[m]);
			    }
			}
		     }
		}
	    }
	    //****************************************************************************************insert 1015/10/31
	    if((Has_junc_l!=0 && Has_junc_r==0) || (Has_junc_r!=0 && Has_junc_l==0)){
		if(Has_junc_l!=0){//left junction right no junction
		    vector<int> L_pair_junc_l,L_pair_junc_r,L_exon_num;
		    Find_junc L_find_junc;
		    L_find_junc.find_junc(left_start,left_map);
		    L_pair_junc_l=L_find_junc.get_read_junc_l();
		    L_pair_junc_r=L_find_junc.get_read_junc_r();
		    vector<int> L_pair_junc_r_last;
		    L_pair_junc_r_last.push_back(L_pair_junc_r.back());
		    L_exon_num=Pair_left_juncr_in_exon(L_pair_junc_r_last,exon_l,exon_r);
		    bool L_exon_multi_in_out=exon_multi_in_out(junc_l,junc_r,exon_l,exon_r,L_exon_num);
		     if(L_exon_multi_in_out){
			for(int m=0;m<L_pair_junc_l.size();m++){
			    pair_junc_l.push_back(L_pair_junc_l[m]);
			    pair_junc_r.push_back(L_pair_junc_r[m]);
			}
			pair_node=Read_in_exon(exon_l,exon_r,right_start);
			if(pair_node!=-1 && !Has_two_exon_junction(exon_l,exon_r,junc_l,junc_r,L_exon_num.back(),pair_node)) pair_node=-2;
		    }
		     else{
			if(L_pair_junc_l.size()>=2){
			    vector<int> mid_junc_l;
			    mid_junc_l.push_back(L_pair_junc_l[1]);
                            vector<int> mid_exon_num=Pair_right_juncl_in_exon(mid_junc_l,exon_l,exon_r);
                            bool mid_exon_multi_in_out(exon_multi_in_out(junc_l,junc_r,exon_l,exon_r,mid_exon_num));
			    if(mid_exon_multi_in_out){
			    	for(int m=0;m<L_pair_junc_l.size();m++){
			    	    pair_junc_l.push_back(L_pair_junc_l[m]);
			 	    pair_junc_r.push_back(L_pair_junc_r[m]);
			        }
			    }
			}
		     } 
		}
		else{
		    vector<int> R_pair_junc_l,R_pair_junc_r,R_exon_num;
		    Find_junc R_find_junc;
		    R_find_junc.find_junc(right_start,right_map);
		    R_pair_junc_l=R_find_junc.get_read_junc_l();
		    R_pair_junc_r=R_find_junc.get_read_junc_r();
		    vector<int> R_pair_junc_l_first;
		    R_pair_junc_l_first.push_back(R_pair_junc_l[0]);
//cout<<R_pair_junc_l[0]<<endl;
		    R_exon_num=Pair_right_juncl_in_exon( R_pair_junc_l_first,exon_l,exon_r);
//cout<<R_exon_num[0]<<" "<<R_exon_num.back()<<endl;
		    bool R_exon_multi_in_out=exon_multi_in_out(junc_l,junc_r,exon_l,exon_r,R_exon_num);
//cout<<R_exon_multi_in_out<<endl;
		    if( R_exon_multi_in_out ) {
			for(int m=0;m<R_pair_junc_l.size();m++){
			    pair_junc_l.push_back(R_pair_junc_l[m]);
			    pair_junc_r.push_back(R_pair_junc_r[m]);
			}
			Find_junc L_find_junc;
		   	L_find_junc.find_junc(left_start,left_map);
			int left_last_map=L_find_junc.get_last_map();
		 	//cout<<left_last_map<<endl;
			left_last_map=left_last_map+left_start-1;
			//cout<<left_last_map<<endl;
			pair_node=Read_in_exon(exon_l,exon_r,left_last_map);
			//cout<<pair_node<<" "<<R_exon_num[0]<<endl;
			if(pair_node!=-1 && !Has_two_exon_junction(exon_l,exon_r,junc_l,junc_r,pair_node,R_exon_num[0])) pair_node=-2;
			//cout<<pair_node<<endl;
		    }
		    else{
//cout<<"h"<<endl;
			if(R_pair_junc_l.size()>=2){
			    vector<int> mid_junc_l;
                            mid_junc_l.push_back(R_pair_junc_l[1]);
                            vector<int> mid_exon_num=Pair_right_juncl_in_exon(mid_junc_l,exon_l,exon_r);
                            bool mid_exon_multi_in_out(exon_multi_in_out(junc_l,junc_r,exon_l,exon_r,mid_exon_num));
                            if(mid_exon_multi_in_out){
			    	for(int m=0;m<R_pair_junc_l.size();m++){
				    pair_junc_l.push_back(R_pair_junc_l[m]);
                                    pair_junc_r.push_back(R_pair_junc_r[m]);
				}

			    }
			}
		    }
		    
		}
	    }
	    //****************************************************************************************insert 1015/10/31
	}//pair两端都在当前基因内finish
	else i++;
/*	if(num==1){//pair一端都在当前基因内
            vector<string> start_map;
            start_map=i->second;
            int start;
            string map,s;

            s=start_map[0];
            start=atoi(s.c_str());
            map=start_map.back();
            if(Has_junc(map)!=0){
                 Find_junc find_junc;
                 find_junc.find_junc(start,map);
                 pair_junc_l=find_junc.get_junc_l();
                 pair_junc_r=find_junc.get_junc_r();
            }
	    i++;
        }*/
//cout<<pair_junc_l.size()<<endl;
	if(pair_node!=-2){
	for(int i=0;i<pair_junc_l.size();i++){
//cout<<i<<endl;
	    for(int j=0;j<junc_l.size();j++){

	        if(pair_junc_l[i]==junc_l[j]&&pair_junc_r[i]==junc_r[j]){
	    	    edge_cur.push_back(j);
		}
 	    }
		for(int k=0;k<exon_l.size();k++){
		    if(pair_junc_l[i]-1==exon_r[k]) node_cur.push_back(k);
		    if(pair_junc_r[i]==exon_l[k]) node_cur.push_back(k);
		}
	}
	}
	if(pair_node!=-1 && pair_node!=-2) node_cur.push_back(pair_node);
	for(int i=0;i<edge_cur.size();i++){
	    for(int j=0;j<node_cur.size();j++){
		if(node_cur[j]>=0){
		    m_edge_node.insert(pair<int,int> (edge_cur[i],node_cur[j]));
		}
	        //Edge.push_back(edge_cur[i]);
	        //Node.push_back(node_cur[j]);
	    }
	}
    }//整个multimap结束；
//cout<<"hhhh"<<endl;
    for(iter_i i=m_edge_node.begin();i!=m_edge_node.end();){
	vector<int>node_same_edge;
	int same_edge=i->first;
	iter_i lower=m_edge_node.lower_bound(same_edge);
	iter_i upper=m_edge_node.upper_bound(same_edge);
	i=upper;
	for(iter_i j=lower;j!=upper;j++) {
	    node_same_edge.push_back(j->second);
	}
	sort(node_same_edge.begin(), node_same_edge.end() );
	vector<int>::iterator iter_end;
	iter_end = unique( node_same_edge.begin(),  node_same_edge.end() );
	node_same_edge.erase(iter_end, node_same_edge.end() );
	for(int k=0;k< node_same_edge.size();k++){
	     Edge.push_back(same_edge);
	     Node.push_back(node_same_edge[k]);
	}
    }
/*for(int m=0;m<Edge.size();m++);
    if(Edge.size()>0){
        for(int i1=0;i1<Edge.size()-1;i1++){
            int index=i1;
            for(int j=i1+1;j<Node.size();){
                if(Edge[j]==Edge[index] && Node[j]==Node[index]){
                    Edge.erase(Edge.begin()+j);
                    Node.erase(Node.begin()+j);
                }
                else j++;
            }
        }
    }*/
}
vector<int> Edge_Node_Pair::get_Edge(){return Edge;}
   vector<int> Edge_Node_Pair::get_Node(){return Node;}
