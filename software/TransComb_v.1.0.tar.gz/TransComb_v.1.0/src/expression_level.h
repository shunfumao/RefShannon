#ifndef EXPRESSION_LEVEL
#define EXPRESSION_LEVEL

#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<vector>
#include<stdlib.h>
#include<algorithm>
#include<cstring>
#include"QuadProg++.cc"
#include"matrix_process.h"
using namespace std;

//junction_graph.DAG_left    junction_graph.DAG_right    junction_graph.DAG_weights    decompose_min_flow.Path_cover
class Express_Level
{
	private:
	vector<int> DAG_left;
	vector<int> DAG_right;
	vector<double> DAG_weights;
	vector<vector<int> > Path_cover;
	vector<int> Seeds_num;
	public:
	Express_Level(vector<int> dag_left, vector<int> dag_right, vector<double> dag_weights, vector<int> seeds_num, vector<vector<int> > path_cover);
	~Express_Level();
	void Compute_Express_Level();
	vector<double> Level;
	vector<double> B;
	vector<vector<double> > A;
};
Express_Level::Express_Level(vector<int> dag_left, vector<int> dag_right, vector<double> dag_weights, vector<int> seeds_num, vector<vector<int> > path_cover)
{
	DAG_left=dag_left;
	DAG_right=dag_right;
	DAG_weights=dag_weights;
	Seeds_num=seeds_num;
	Path_cover=path_cover;
	return;
}
Express_Level::~Express_Level()
{
	return;
}
void Express_Level::Compute_Express_Level()
{
	int i,j,k,t,m,n;
	double temp;
	m=Path_cover.size();
	n=Seeds_num.size();
//	n=DAG_weights.size();
	vector<double> A_temp;
	vector<vector<double> > P;
	for (i=0;i<Seeds_num.size();i++)
	{	
		for (j=0;j<Path_cover.size();j++)
		{
			t=0;
			for (k=0;k<Path_cover[j].size()-1;k++)
			{
				if (Path_cover[j][k]==DAG_left[Seeds_num[i]] && Path_cover[j][k+1]==DAG_right[Seeds_num[i]])
				{	
					A_temp.push_back(1);
					break;
				}
				else
				{
					t++;
				}
		 	 }
		 	 if (t==int(Path_cover[j].size()-1))
		 	 {
		  		A_temp.push_back(0);
		 	 }
	  	}
	  P.push_back(A_temp);
	  A_temp.clear();
	}
	for (i=0;i<m;i++)
	{
		for (j=0;j<m;j++)
		{
			temp=0;
			if (i==j)
			{
				for (k=0;k<n;k++)
				{
					temp=temp+P[k][j];
				}
				A_temp.push_back(temp);
			}
			else
			{
				for (k=0;k<n;k++)
				{
					temp=temp+P[k][i]*P[k][j];
				}
				A_temp.push_back(temp);
			}
		}
		A.push_back(A_temp);
		A_temp.clear();
	}
	double B_temp;
	for (i=0;i<m;i++)
	{
		B_temp=0;
		for (j=0;j<n;j++)
		{
			B_temp=B_temp+P[j][i]*DAG_weights[Seeds_num[j]];
		}
		B.push_back(B_temp);
	}
	double G[MATRIX_DIM][MATRIX_DIM], g0[MATRIX_DIM], CI[MATRIX_DIM][MATRIX_DIM], ci0[MATRIX_DIM], x[MATRIX_DIM];
	double CE[MATRIX_DIM][MATRIX_DIM], ce0[MATRIX_DIM];
	for (i=0;i<A.size();i++)
	{
		for (j=0;j<A[i].size();j++)
		{
			G[i][j]=2*A[i][j];
			if (i==j)
			{
				G[i][j]=2*A[i][j]+0.000001;
				CI[i][j]=1.0;
			}
			else
			{
				G[i][j]=2*A[i][j];
				CI[i][j]=0.0;
			}
		}
		g0[i]=-2*B[i];
		ci0[i]=0.0;
	}
	solve_quadprog(G, g0, int(B.size()), CE, ce0, 0, CI, ci0, int(B.size()), x);
	for (i=0;i<int(B.size());i++)
	{
		if (x[i]<0.00001)
		{
			Level.push_back(0);
		}
		else
		{
			Level.push_back(x[i]);
		}
	}
/*	
	cout<<"x: "<<endl;
	for (i=0;i<int(B.size());i++)
	{
		cout<<x[i]<<"; "<<endl;
	}
*/
}
	  
#endif



















