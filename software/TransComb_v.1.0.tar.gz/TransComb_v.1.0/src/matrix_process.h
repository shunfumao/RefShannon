//  matrix_process.h
#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<vector>
#include<stdlib.h>
#include<algorithm>
#include<cstring>
using namespace std;

vector<int> vec_matrix(vector<int> vec, vector<vector<int> > matrix) 
{
	int i,j,k,temp_sum;
	vector<int> vec_result;
	if (vec.size()!=matrix.size())
		cout<<"ERROR MATRIX!!!"<<endl;
	else
	{
		for(i=0;i<matrix[0].size();i++)
		{
			temp_sum=0;
			for (j=0;j<vec.size();j++)
			{
				temp_sum=temp_sum+vec[j]*matrix[j][i];
			}
			vec_result.push_back(temp_sum);
		}
	}
	return vec_result;
}
vector<int> vec_matrix(vector<vector<int> > matrix, vector<int> vec)
{
        int i,j,k,temp_sum;
        vector<int> vec_result;
        if (vec.size()!=matrix[0].size())
                cout<<"ERROR MATRIX!!!"<<endl;
        else
        {
		for (i=0;i<matrix.size();i++)
		{
			temp_sum=0;
			for (j=0;j<vec.size();j++)                        
			{
                                temp_sum=temp_sum+vec[j]*matrix[i][j];
                        }
                        vec_result.push_back(temp_sum);
		}
	}
	return vec_result;
}
int vec_matrix(vector<int> vec_1, vector<int> vec_2)
{
	int i,j,k,vec_result;
	if (vec_1.size()!=vec_2.size())
		cout<<"ERROR MATRIX!!!"<<endl;
        else
        {
		vec_result=0;
		for (i=0;i<vec_1.size();i++)
		{
			vec_result=vec_result+vec_1[i]*vec_2[i];
		}
	}
	return vec_result;
}
// float * int
vector<float> vec_matrix(vector<float> vec, vector<vector<int> > matrix) 
{
	int i,j,k;
	float temp_sum;
	vector<float> vec_result;
	if (vec.size()!=matrix.size())
		cout<<"ERROR MATRIX!!!"<<endl;
	else
	{
		for(i=0;i<matrix[0].size();i++)
		{
			temp_sum=0;
			for (j=0;j<vec.size();j++)
			{
				temp_sum=temp_sum+vec[j]*matrix[j][i];
			}
			vec_result.push_back(temp_sum);
		}
	}
	return vec_result;
}
vector<float> vec_matrix(vector<float> vec, vector<vector<float> > matrix) 
{
	int i,j,k;
	float temp_sum;
	vector<float> vec_result;
	if (vec.size()!=matrix.size())
		cout<<"ERROR MATRIX!!!"<<endl;
	else
	{
		for(i=0;i<matrix[0].size();i++)
		{
			temp_sum=0;
			for (j=0;j<vec.size();j++)
			{
				temp_sum=temp_sum+vec[j]*matrix[j][i];
			}
			vec_result.push_back(temp_sum);
		}
	}
	return vec_result;
}
vector<float> vec_matrix(vector<vector<float> > matrix, vector<float> vec)
{
        int i,j,k;
	float temp_sum;
        vector<float> vec_result;
        if (vec.size()!=matrix[0].size())
                cout<<"ERROR MATRIX!!!"<<endl;
        else
        {
		for (i=0;i<matrix.size();i++)
		{
			temp_sum=0;
			for (j=0;j<vec.size();j++)                        
			{
                                temp_sum=temp_sum+vec[j]*matrix[i][j];
                        }
                        vec_result.push_back(temp_sum);
		}
	}
	return vec_result;
}
double vec_matrix(vector<float> vec_1, vector<float> vec_2)
{
	int i,j,k;
	double vec_result;
	if (vec_1.size()!=vec_2.size())
		cout<<"ERROR MATRIX!!!"<<endl;
        else
        {
		vec_result=0;
		for (i=0;i<vec_1.size();i++)
		{
			vec_result=vec_result+vec_1[i]*vec_2[i];
		}
	}
	return vec_result;
}














