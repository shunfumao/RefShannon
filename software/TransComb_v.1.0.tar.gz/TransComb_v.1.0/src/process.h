#include<iostream>
#include<string>
#include<algorithm>
#include<vector>
#include<fstream>
#include<sstream>
#include<map>
#include<cstring>
#include<stdlib.h>
#include"describe_graph.h"
#include"Find_junc_last_map.h"
#include"Insert.h"
#include"edge_node_pair.h"
#include"False_junc.h"
#include"sep_gene.h"
	extern double SEP_EXON_RATE;
	extern double Mul_RATE;
	extern double COV_RATE;
	extern double RATE;
	
void process_gene(int count,vector<int> exon_l,vector<int> exon_r,vector<int> junc_l,vector<int>junc_r,vector<int> seg_l,vector<int> seg_r,vector<int> seg_NH,vector<double> exon_cov,vector<double> junc_cov,vector<double> v_Gene,map<vector<int>, double> Read,int READ_LENGTH,char * out_name,string cov_filter,int strand,int line,int XS_plus,int XS_minus,vector<string> ch_note,int gene_l,multimap <string,vector<string> > m_id_map){
		    //pair support
	    	    for(int i=0;i<exon_l.size()-1;i++){
	                int pair_count=0;
	                if(!is_in(exon_r[i]+1,junc_l) && !is_in(exon_l[i+1],junc_r) && is_in(exon_l[i],junc_r) && is_in(exon_r[i+1]+1,junc_l)){
	                    //cout<<"E: "<<exon_l[i]<<" "<<exon_r[i]<<" "<<exon_l[i+1]-exon_r[i]<<" "<<exon_l[i+1]<<" "<<exon_r[i+1];
	                    for(multimap <string,vector<string> >::iterator j=m_id_map.begin();j!=m_id_map.end();){
	                        string read_id=j->first;
	                        int num=m_id_map.count(read_id);
	                        if(num==2){
	                            multimap <string,vector<string> >::iterator lower=m_id_map.lower_bound(read_id);//返回当前键值的第一个位置
	                            j=m_id_map.upper_bound(read_id);//返回当前键值对应的下一个键值的第一个位置
	                            vector<string> left_start_map,right_start_map;
	                            left_start_map=lower->second;
	                            lower++;
	                            multimap <string,vector<string> >::iterator last=lower;
	                            right_start_map=last->second;
	                            int left_start,right_start;
	                            string left_map,right_map,s;
	                            s=left_start_map[0];
	                            left_start=atoi(s.c_str());
	                            left_map=left_start_map.back();
	                            s=right_start_map[0];
	                            right_start=atoi(s.c_str());
	                            right_map=right_start_map.back();
	                            int last_site=Read_last_site(left_start,left_map);
	                            if(last_site>exon_l[i] && last_site<=exon_r[i] && right_start>=exon_l[i+1] && right_start<exon_r[i+1]) {
	                                pair_count++;
	                            }
	                        }
	                        else j++;
	                    }
	                    //cout<<" "<<pair_count<<endl;
	                    /*
			    if(pair_count>=1 && exon_l[i+1]-exon_r[i]<200){
				for(int k=exon_r[i]-gene_l+1;k<exon_l[i+1]-gene_l;k++) {v_Gene[k]=pair_count;}
				exon_r.erase(exon_r.begin()+i);
				exon_l.erase(exon_l.begin()+i+1);
			    }
			*/
	                }
	            }
	
	//for(int i=0;i<exon_l.size();i++) cout<<exon_l[i]<<" "<<exon_r[i]<<endl;
	//******************************************************************************************************11/19 up
		    int count_partial=0;
		    for(int i=1;i<exon_l.size();i++){
			if(exon_l[i]-exon_r[i-1]==1) count_partial++;
		    }
		    if(exon_l.size()>1&& count_partial>=10){
		    for(int i=0;i<exon_l.size()-1;i++){
			if(exon_r[i]-exon_l[i]+1>=200){
	    		    vector<double> exon_site;
			    for(int k=exon_l[i]-gene_l;k<=exon_r[i]-gene_l;k++){
			    	exon_site.push_back(v_Gene[k]);
			    }
			    double cov_l=0;double cov_r=0;
			    double cov_min=0;int seq_site;
			    for(int j=0;j<50;j++) cov_l=cov_l+exon_site[j];
			    for(int j=exon_site.size()-1;j>exon_site.size()-51;j--) cov_r=cov_r+exon_site[j];
			    if(cov_l<cov_r) {cov_min=cov_l;seq_site=0;}
			    else {cov_min=cov_r;seq_site=exon_site.size()-50;}
			    for(int j=50;j<=exon_site.size()-102;j++){
				double win_cov=0;
				for(int l=j;l<j+50;l++){
				    win_cov=win_cov+exon_site[l];
				}
				if(cov_min>win_cov) {cov_min=win_cov;seq_site=j;}
			    }
			    if(cov_min/cov_l<SEP_EXON_RATE && cov_min/cov_r<SEP_EXON_RATE ){
				for(int l=exon_l[i]-gene_l+seq_site;l<exon_l[i]-gene_l+seq_site+50;l++){v_Gene[l]=0;}
				exon_r=insert(exon_r,i,exon_l[i]+seq_site-1);
				exon_l=insert(exon_l,i+1,exon_l[i]+seq_site+50);
				i++;
			    }
			}
		    }
		    }
	
		    if(count==0){//没删除junction
	//cout<<"no_dele"<<endl;
			for(int i1=0;i1<exon_l.size();i1++){
	                    double  k=0.00000;
	                    for(int i2=exon_l[i1]-gene_l;i2<=exon_r[i1]-gene_l;i2++){
	                        k=k+v_Gene[i2];
	                    }
	                    double cov=k/(exon_r[i1]-exon_l[i1]+1);
	                    exon_cov.push_back(cov);
	                }
	
			if(exon_l.size()>1 || (exon_l.size()==1&&exon_cov[0]>3&&exon_r[0]-exon_l[0]>=250)){
			const string & basename = base_name();
	//*********************************************************************************************************2015//11//15 u
	//for(int i=0;i<exon_l.size();i++) cout<<exon_l[i]<<" "<<exon_r[i]<<endl;
			if(exon_l.size()>1){
	           	     for(int i=1;i<exon_l.size()-1;){
	                	 if((exon_l[i]-exon_r[i-1]==1|| exon_l[i+1]-exon_r[i]==1)&&!is_in(exon_l[i],junc_r)&&!is_in(exon_r[i]+1,junc_l)&&(exon_cov[i]<10)){
	                    	     exon_l.erase(exon_l.begin()+i);
	                   	     exon_r.erase(exon_r.begin()+i);
				     exon_cov.erase(exon_cov.begin()+i);
	                    	}
	               		 else i++;
	        	    }
		        }
	
	//for(int i=0;i<exon_l.size();i++) cout<<exon_l[i]<<" --- "<<exon_r[i]<<endl;
			    vector<int> false_junc;
	                    vector<double> false_junc_cov;
	                    false_junc=False_junc(exon_l,exon_r);
	                    if(false_junc.size()>0){false_junc_cov=False_junc_cov(false_junc,seg_l,seg_r,seg_NH);}
			    for(int i=0;i<false_junc.size();){
				if(false_junc_cov[i]<2){
				    false_junc.erase(false_junc.begin()+i);
				    false_junc_cov.erase(false_junc_cov.begin()+i);
				}
				else i++;
			    }
	//for(int i=0;i<junc_l.size();i++){cout<<junc_l[i]<<" "<<junc_r[i]<<"*************"<<endl;}
	//for(int i=0;i<false_junc.size();i++){cout<<false_junc[i]<<endl;}cout<<endl;
			    if(junc_l.size()>0){
			    for(int i=0;i<false_junc.size();i++){
				for(int j=junc_l.size()-1;j>0;j--){
				    if(false_junc[i]+1<=junc_l[j] && false_junc[i]+1>junc_l[j-1]){
	//cout<<false_junc[i]<<" %%"<<endl;
					junc_l=insert(junc_l,j,false_junc[i]+1);
					junc_r=insert(junc_r,j,false_junc[i]+1);
					junc_cov=insert_d(junc_cov,j,false_junc_cov[i]);
					break;
				    }
				}
			    
				if(false_junc[i]+1>junc_l.back()){
				    junc_l.push_back(false_junc[i]+1);
				    junc_r.push_back(false_junc[i]+1);
				    junc_cov.push_back(false_junc_cov[i]);
				}
				if(false_junc[i]+1<=junc_l[0]){
	//cout<<false_junc[i]<<" %%"<<endl;
				     junc_l=insert(junc_l,0,false_junc[i]+1);
	                             junc_r=insert(junc_r,0,false_junc[i]+1);
	                             junc_cov=insert_d(junc_cov,0,false_junc_cov[i]);
				}
			    }
			    
			    }
	//for(int i=0;i<junc_l.size();i++){cout<<junc_l[i]<<" "<<junc_r[i]<<"&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&"<<endl;}
			    vector<int> partial_junc=false_junc;
			    false_junc.clear();false_junc_cov.clear();
	 		    vector<int> junc_l_cur=junc_l;vector<int>junc_r_cur=junc_r; vector<double> junc_cov_cur=junc_cov;
			if(count_partial>=10){
	    		    for(int k=0;k<junc_l.size();k++){
				if(junc_cov[k]<=35){
				    int exon_l_num=juncl_in_exon(junc_l[k],exon_l,exon_r);
				    int exon_r_num=juncr_in_exon(junc_r[k],exon_l,exon_r);
				    Exon_edge Left_exon;
				    Left_exon.find_exon_edge(exon_l_num,exon_l,exon_r,junc_l,junc_r,junc_cov,false_junc,false_junc_cov);
				    vector<int> LIn_junc_l,LIn_junc_r,LOut_junc_l,LOut_junc_r;
				    vector<double> LIn_junc_cov,LOut_junc_cov;
				    LIn_junc_l=Left_exon.get_In_junc_l();
	           	            LIn_junc_r=Left_exon.get_In_junc_r();
	            		    LIn_junc_cov=Left_exon.get_In_junc_cov();
		                    LOut_junc_l=Left_exon.get_Out_junc_l();
	            	    	    LOut_junc_r=Left_exon.get_Out_junc_r();
		                    LOut_junc_cov=Left_exon.get_Out_junc_cov();
				    Exon_edge Right_exon;
		                    Right_exon.find_exon_edge(exon_r_num,exon_l,exon_r,junc_l,junc_r,junc_cov,false_junc,false_junc_cov);
	            		    vector<int> RIn_junc_l,RIn_junc_r,ROut_junc_l,ROut_junc_r;
		                    vector<double> RIn_junc_cov,ROut_junc_cov;
	            		    RIn_junc_l=Right_exon.get_In_junc_l();
		                    RIn_junc_r=Right_exon.get_In_junc_r();
	               		    RIn_junc_cov=Right_exon.get_In_junc_cov();
			            ROut_junc_l=Right_exon.get_Out_junc_l();
	            		    ROut_junc_r=Right_exon.get_Out_junc_r();
		                    ROut_junc_cov=Right_exon.get_Out_junc_cov();
				    if(LOut_junc_l.size()==1 && LIn_junc_l.size()>0){
					double In_cov=0;
					for(int t=0;t<LIn_junc_l.size();t++){In_cov=In_cov+LIn_junc_cov[t];}
					double rate=junc_cov[k]/In_cov;
					if(rate<RATE){
					    junc_l_cur[k]=0;
					    junc_r_cur[k]=0;
					    junc_cov_cur[k]=0;
					}
				    }
				    if(RIn_junc_l.size()==1 && ROut_junc_l.size()>0){
					double Out_cov=0;
					for(int t=0;t<ROut_junc_l.size();t++){Out_cov=Out_cov+ROut_junc_cov[t];}
					double rate=junc_cov[k]/Out_cov;
					if(rate<RATE){
					    junc_l_cur[k]=0;
					    junc_r_cur[k]=0;
	                                    junc_cov_cur[k]=0;
					}
				    }
				    if(LOut_junc_l.size()>=2 && is_in(LOut_junc_l[0]-1,partial_junc)){
				 	double partial_cov;
					for(int t=0;t<LOut_junc_l.size();t++){
	                                    if(LOut_junc_r[t]==LOut_junc_l[t]) partial_cov=LOut_junc_cov[t];
	                                }
					if(junc_cov[k]/partial_cov<Mul_RATE){
					    junc_l_cur[k]=0;
	                                    junc_r_cur[k]=0;
	                                    junc_cov_cur[k]=0;
					}
				    }
				    if(RIn_junc_l.size()>=2 && is_in(RIn_junc_r[0]-1,partial_junc)){
					double partial_cov;
					for(int t=0;t<RIn_junc_l.size();t++){
	                                    if(RIn_junc_l[t]==RIn_junc_r[t]) partial_cov=RIn_junc_cov[t];
	                                }
				 	if(junc_cov[k]/partial_cov<Mul_RATE){
	                                    junc_l_cur[k]=0;
	                                    junc_r_cur[k]=0;
	                                    junc_cov_cur[k]=0;
	                                }
				    }
				}
			    }
			}
			    for(int t=0;t<junc_l_cur.size();){
				if(junc_l_cur[t]==0){
				    junc_l_cur.erase(junc_l_cur.begin()+t);
				    junc_r_cur.erase(junc_r_cur.begin()+t);
				    junc_cov_cur.erase(junc_cov_cur.begin()+t);
				    
				}
				else t++;
			    }
			    junc_l=junc_l_cur;junc_r=junc_r_cur;junc_cov=junc_cov_cur;
	
			    if(junc_cov.size()>0){
				double max_cov=*max_element(junc_cov.begin(),junc_cov.end());
	                        for(int i=0;i<junc_cov.size();){
	                            if(junc_cov[i]/max_cov<=COV_RATE){
	                                junc_l.erase(junc_l.begin()+i);
	                                junc_r.erase(junc_r.begin()+i);
	                                junc_cov.erase(junc_cov.begin()+i);
	                            }
	                            else i++;
	                        }
	
			    }
	
	//for(int i=0;i<junc_l.size();i++)cout<<junc_l[i]<<" "<<junc_r[i]<<endl;
	//*********************************************************************************************************2015//11//15 b
			    vector<int> node_l,node_r;
			    vector<double> edge_cov;
			    for (int i=0;i<junc_l.size();i++){
	            		 for(int j=0;j<exon_l.size();j++){
		                    if(junc_l[i]-1==exon_r[j]) node_l.push_back(j);
	            	            if(junc_r[i]==exon_l[j]) {node_r.push_back(j);edge_cov.push_back(junc_cov[i]);}
	        	        }
	        	    }
		            for(int i=0;i<false_junc.size();i++){
	        	    	for(int j=0;j<exon_l.size();j++){
		                    if(false_junc[i]==exon_r[j]&&false_junc_cov[i]>=2){node_l.push_back(j);node_r.push_back(j+1);edge_cov.push_back(false_junc_cov[i]);}
	            		}
	        	    }
			    if(node_l.size()==0){
				vector<int> pair_edge,pair_node;
//				const string & basename = base_name();
	                        const string name = "./RawGraphs/" + basename + ".rg";
	                        save_debug(name + ".debug",gene_l,junc_l,junc_r,junc_cov,exon_l,exon_r,exon_cov,pair_edge,pair_node,ch_note.back(),false_junc,false_junc_cov,v_Gene,Read,READ_LENGTH,out_name,cov_filter,strand,line,XS_plus,XS_minus);
			    }
			    map<int,int> node_in_all_sub;
			    typedef map<int,int>::iterator ite;
			    while(node_l.size()>0){//需要找连通分支
				map<int,int> con_subgraph;
				vector<int> exon_l_con,exon_r_con,junc_l_con,junc_r_con,false_junc_con;
				vector<double>junc_cov_con,false_junc_cov_con,exon_cov_con;
				con_subgraph.insert(pair<int,int> (node_l[0],1));
				con_subgraph.insert(pair<int,int> (node_r[0],1));
				node_l.erase(node_l.begin());node_r.erase(node_r.begin());
				for(ite it=con_subgraph.begin();it!=con_subgraph.end();it++){
			   	   for(int i=0;i<node_l.size();){
					if(node_l[i]==it->first || node_r[i]==it->first){
					    con_subgraph.insert(pair<int,int> (node_l[i],1));
					    con_subgraph.insert(pair<int,int> (node_r[i],1));
					    node_l.erase(node_l.begin()+i);node_r.erase(node_r.begin()+i);
					    edge_cov.erase(edge_cov.begin()+i);
					    it=con_subgraph.begin();
					}
					else i++;
				   }
				}
				if(con_subgraph.size()==exon_l.size()){//图是联通的
				    for(int it=0;it<exon_l.size();it++)node_in_all_sub.insert(pair<int,int> (it,1));
				    exon_l_con=exon_l;
				    exon_r_con=exon_r;
				    exon_cov_con=exon_cov;
				    junc_l_con=junc_l;
				    junc_r_con=junc_r;
				    junc_cov_con=junc_cov;
				    false_junc_con=false_junc;
				    false_junc_cov_con=false_junc_cov;
				}
				else{
				    for(ite it=con_subgraph.begin();it!=con_subgraph.end();it++){
				    	 int k=it->first;
					 node_in_all_sub.insert(pair<int,int> (k,1));
				    	 exon_l_con.push_back(exon_l[k]);
				    	 exon_r_con.push_back(exon_r[k]);
				    	 exon_cov_con.push_back(exon_cov[k]);
				    	 for(int i=0;i<junc_l.size();i++){
					     if(junc_l[i]-1==exon_r[k]){junc_l_con.push_back(junc_l[i]);junc_r_con.push_back(junc_r[i]);junc_cov_con.push_back(junc_cov[i]);}
				 	     if(junc_l[i]-1>exon_r[k]) break;    
				         }
				         for(int i=0;i<false_junc.size();i++){
					     if(false_junc[i]==exon_r[k]){false_junc_con.push_back(false_junc[i]);false_junc_cov_con.push_back(false_junc_cov[i]);}
				     	 }
				    }
				}
				Edge_Node_Pair ENP;
	                        ENP.Find_edge_node(exon_l_con,exon_r_con,junc_l_con,junc_r_con,m_id_map);
	                        vector<int> pair_edge,pair_node;
	                        pair_edge=ENP.get_Edge();
	                        pair_node=ENP.get_Node();
//				const string & basename = base_name();
				const string name = "./RawGraphs/" + basename + ".rg";
				save_debug(name + ".debug",gene_l,junc_l_con,junc_r_con,junc_cov_con,exon_l_con,exon_r_con,exon_cov_con,pair_edge,pair_node,ch_note.back(),false_junc_con,false_junc_cov_con,v_Gene,Read,READ_LENGTH,out_name,cov_filter,strand,line,XS_plus,XS_minus);
			    }
	if(exon_l.size()>1){
			    for(int i=0;i<exon_l.size();i++){
				ite index;
				index=node_in_all_sub.find(i);
				if(index==node_in_all_sub.end()&&exon_r[i]-exon_l[i]>=250&&exon_cov[i]>3){
//				    const string & basename = base_name();
	                            const string name = "./RawGraphs/" + basename + ".rg";
	                            vector<int>exon_l_con,exon_r_con,junc_l_con,junc_r_con,false_junc_con,pair_edge,pair_node;
	                            vector<double>exon_cov_con,junc_cov_con,false_junc_cov_con;
	                            exon_l_con.push_back(exon_l[i]);
	                            exon_r_con.push_back(exon_r[i]);
	                            exon_cov_con.push_back(exon_cov[i]);
	                            save_debug(name + ".debug",gene_l,junc_l_con,junc_r_con,junc_cov_con,exon_l_con,exon_r_con,exon_cov_con,pair_edge,pair_node,ch_note.back    (),false_junc_con,false_junc_cov_con,v_Gene,Read,READ_LENGTH,out_name,cov_filter,strand,line,XS_plus,XS_minus);
				}
			    }
	}
			}
		    }
		    if(count!=0){
			const string & basename = base_name();
	//cout<<"dele"<<endl;
			sep_gene sep;
	                sep.find_gene_bound(junc_l,junc_r,exon_l,exon_r);
	                vector<int> gene_l_sep,gene_r_sep;
	                gene_l_sep=sep.get_gene_l();
	                gene_r_sep=sep.get_gene_r();
	//for(int kk=0;kk<gene_l_sep.size();kk++)
	//cout<<"*************** "<<gene_l_sep[kk]<<" "<<gene_r_sep[kk]<<endl;
	
			for(int i1=0;i1<gene_l_sep.size();i1++){
	                    vector<int> exon_l_s,exon_r_s,junc_l_s,junc_r_s;
	                    vector<double> junc_cov_s,v_exon_cov_s;
	                    for(int i2=0;i2<exon_l.size();i2++){
	                        if(exon_l[i2]>=gene_l_sep[i1]&&exon_r[i2]<=gene_r_sep[i1]){
	                            exon_l_s.push_back(exon_l[i2]);
	                            exon_r_s.push_back(exon_r[i2]);
	                        }
	                    }
			    for(int i3=0;i3<junc_l.size();i3++){
	                        if(junc_l[i3]>=gene_l_sep[i1]&&junc_r[i3]<=gene_r_sep[i1]){
	                            junc_l_s.push_back(junc_l[i3]);
	                            junc_r_s.push_back(junc_r[i3]);
	                            junc_cov_s.push_back(junc_cov[i3]);
	                        }
	                    }
			    for(int i2=0;i2<exon_l_s.size();i2++){
	                        double k=0.00000;
				for(int i3=exon_l_s[i2]-gene_l;i3<=exon_r_s[i2]-gene_l;i3++){
	                            k=k+v_Gene[i3];
	                        }
	                        double cov=k/(exon_r_s[i2]-exon_l_s[i2]+1);
	                        v_exon_cov_s.push_back(cov);
	                    }
	
			    if(exon_l_s.size()>1 || (exon_l_s.size()==1&&v_exon_cov_s[0]>3&&exon_r_s[0]-exon_l_s[0]>=250)){
	//******************************************************************************************************************************2015/11/15 u
	//for(int ii=0;ii<exon_l_s.size();ii++) cout<<ii<<"  "<<exon_l_s[ii]<<" "<<exon_r_s[ii]<<endl;
				//vector<int> junc_l_cur=junc_l_s;vector<int>junc_r_cur=junc_r_s; vector<double> junc_cov_cur=junc_cov_s;
			        if(exon_l_s.size()>1){
	                 	    for(int i=1;i<exon_l_s.size()-1;){
	                        	 if((exon_l_s[i+1]-exon_r_s[i]==1 || exon_l_s[i]-exon_r_s[i-1]==1)&&!is_in(exon_l_s[i],junc_r_s)&&!is_in(exon_r_s[i]+1,junc_l_s)&&(v_exon_cov_s[i]<10)){
	                            		 exon_l_s.erase(exon_l_s.begin()+i);
			                         exon_r_s.erase(exon_r_s.begin()+i);
	                		         v_exon_cov_s.erase(v_exon_cov_s.begin()+i);
	                        	}
		                        else i++;
	        	            }
	                	}
	//for(int ii=0;ii<exon_l_s.size();ii++)cout<<ii<<" ----- "<<exon_l_s[ii]<<" "<<exon_r_s[ii]<<endl;
	//for(int ii=0;ii<exon_l_s.size();ii++){
	//cout<<ii<<" ----- "<<exon_l_s[ii]<<" "<<exon_r_s[ii]<<endl;
	//}
	//cout<<"****************"<<endl;
	//for(int i=0;i<junc_l_s.size();i++){cout<<junc_l_s[i]<<" "<<junc_r_s[i]<<"**********"<<endl;}
	//for(int i=0;i<false_junc.size();i++){cout<<false_junc[i]<<endl;}cout<<endl;
	                        vector<int> false_junc;
	                        vector<double> false_junc_cov;
	                        false_junc=False_junc(exon_l_s,exon_r_s);
	                        if(false_junc.size()>0){false_junc_cov=False_junc_cov(false_junc,seg_l,seg_r,seg_NH);}
				for(int i=0;i<false_junc.size();){
				    if(false_junc_cov[i]<2){
					false_junc.erase(false_junc.begin()+i);
					false_junc_cov.erase(false_junc_cov.begin()+i);
				    }
				    else i++;
				}
	
	//for(int i=0;i<false_junc.size();i++){cout<<false_junc[i]<<" -- "<<false_junc_cov[i]<<endl;}cout<<endl;
	//for(int i=0;i<junc_l_s.size();i++){cout<<junc_l_s[i]<<" "<<junc_r_s[i]<<" "<<junc_cov_s[i]<<"&&&&&&&&&&&"<<endl;}
				if(junc_l_s.size()>0){
	                        for(int i=0;i<false_junc.size();i++){
	                            for(int j=junc_l_s.size()-1;j>0;j--){
	                                if(false_junc[i]+1<=junc_l_s[j] && false_junc[i]+1>junc_l_s[j-1]){
	                                    junc_l_s=insert(junc_l_s,j,false_junc[i]+1);
	                                    junc_r_s=insert(junc_r_s,j,false_junc[i]+1);
	                                    junc_cov_s=insert_d(junc_cov_s,j,false_junc_cov[i]);
	                                    break;
	                                }
				    }
	                            if(false_junc[i]+1>junc_l_s.back()){
	                                junc_l_s.push_back(false_junc[i]+1);
	                                junc_r_s.push_back(false_junc[i]+1);
	                                junc_cov_s.push_back(false_junc_cov[i]);
	                            }
	                            if(false_junc[i]+1<=junc_l_s[0]){
	                                junc_l_s=insert(junc_l_s,0,false_junc[i]+1);
	                                junc_r_s=insert(junc_r_s,0,false_junc[i]+1);
	                                junc_cov_s=insert_d(junc_cov_s,0,false_junc_cov[i]);
	                            }
	                        }
	                        }  
	//for(int i=0;i<junc_l_s.size();i++){cout<<junc_l_s[i]<<" "<<junc_r_s[i]<<" "<<junc_cov_s[i]<<"&&&&&&&&&&&"<<endl;}  
				vector<int> partial_junc=false_junc;
				false_junc.clear();false_junc_cov.clear();
				vector<int> junc_l_cur=junc_l_s;vector<int>junc_r_cur=junc_r_s; vector<double> junc_cov_cur=junc_cov_s;
			if(count_partial>=10){
				for(int k=0;k<junc_l_s.size();k++){
				    if(junc_cov_s[k]<=35){
					int exon_l_num=juncl_in_exon(junc_l_s[k],exon_l_s,exon_r_s);
				 	int exon_r_num=juncr_in_exon(junc_r_s[k],exon_l_s,exon_r_s);
					Exon_edge Left_exon;
					Left_exon.find_exon_edge(exon_l_num,exon_l_s,exon_r_s,junc_l_s,junc_r_s,junc_cov_s,false_junc,false_junc_cov);
					vector<int> LIn_junc_l,LIn_junc_r,LOut_junc_l,LOut_junc_r;
	                                vector<double> LIn_junc_cov,LOut_junc_cov;
	                                LIn_junc_l=Left_exon.get_In_junc_l();
	                                LIn_junc_r=Left_exon.get_In_junc_r();
	                                LIn_junc_cov=Left_exon.get_In_junc_cov();
	                                LOut_junc_l=Left_exon.get_Out_junc_l();
	                                LOut_junc_r=Left_exon.get_Out_junc_r();
	                                LOut_junc_cov=Left_exon.get_Out_junc_cov();
	                                Exon_edge Right_exon;
					Right_exon.find_exon_edge(exon_r_num,exon_l_s,exon_r_s,junc_l_s,junc_r_s,junc_cov_s,false_junc,false_junc_cov);
					vector<int> RIn_junc_l,RIn_junc_r,ROut_junc_l,ROut_junc_r;
	                                vector<double> RIn_junc_cov,ROut_junc_cov;
	                                RIn_junc_l=Right_exon.get_In_junc_l();
	                                RIn_junc_r=Right_exon.get_In_junc_r();
	                                RIn_junc_cov=Right_exon.get_In_junc_cov();
	                                ROut_junc_l=Right_exon.get_Out_junc_l();
	                                ROut_junc_r=Right_exon.get_Out_junc_r();
	                                ROut_junc_cov=Right_exon.get_Out_junc_cov();
					if(LOut_junc_l.size()==1 && LIn_junc_l.size()>0){
	//cout<<junc_l_s[k]<<"  ----    "<<junc_r_s[k]<<" ";
					    double In_cov=0;
					    for(int t=0;t<LIn_junc_l.size();t++){In_cov=In_cov+LIn_junc_cov[t];}
					    double rate=junc_cov_s[k]/In_cov;
					    if(rate<RATE){
						junc_l_cur[k]=0;
	                                        junc_r_cur[k]=0;
	                                        junc_cov_cur[k]=0;
					    }
					}
					if(RIn_junc_l.size()==1 && ROut_junc_l.size()>0){
	//cout<<junc_l_s[k]<<"  ----    "<<junc_r_s[k]<<" ";
	                                    double Out_cov=0;
	                                    for(int t=0;t<ROut_junc_l.size();t++){Out_cov=Out_cov+ROut_junc_cov[t];}
	//cout<<Out_cov<<endl;
	                                    double rate=junc_cov_s[k]/Out_cov;
	//cout<<rate<<endl;
	                                    if(rate<RATE){
	                                        junc_l_cur[k]=0;
	                                        junc_r_cur[k]=0;
	                                        junc_cov_cur[k]=0;
	                                    }
	                                }
					if(LOut_junc_l.size()>=2 && is_in(LOut_junc_l[0]-1,partial_junc)){
	//cout<<junc_l_s[k]<<"  ----    "<<junc_r_s[k]<<" ";
	                                    double partial_cov;
					    for(int t=0;t<LOut_junc_l.size();t++){
						if(LOut_junc_r[t]==LOut_junc_l[t]) partial_cov=LOut_junc_cov[t];
					    }
	//cout<< partial_cov<<"        "<<junc_cov_s[k]/partial_cov<<endl;
	                                    if(junc_cov_s[k]/partial_cov<Mul_RATE){
	                                        junc_l_cur[k]=0;
	                                        junc_r_cur[k]=0;
	                                        junc_cov_cur[k]=0;
	                                    }
	                                }
	                               if(RIn_junc_l.size()>=2 && is_in(RIn_junc_r[0]-1,partial_junc)){
	                                    double partial_cov;
					    for(int t=0;t<RIn_junc_l.size();t++){
						if(RIn_junc_l[t]==RIn_junc_r[t]) partial_cov=RIn_junc_cov[t];
					    }
	                                    if(junc_cov_s[k]/partial_cov<Mul_RATE){
	                                        junc_l_cur[k]=0;
	                                        junc_r_cur[k]=0;
	                                        junc_cov_cur[k]=0;
	                                    }
	                                }
				    }
				}
			}
				for(int t=0;t<junc_l_cur.size();){
	                            if(junc_l_cur[t]==0){
	                                junc_l_cur.erase(junc_l_cur.begin()+t);
	                                junc_r_cur.erase(junc_r_cur.begin()+t);
	                                junc_cov_cur.erase(junc_cov_cur.begin()+t);
	    
	                            }
				    else t++;
	                        }
	                        junc_l_s=junc_l_cur;junc_r_s=junc_r_cur;junc_cov_s=junc_cov_cur;
			
				if(junc_cov_s.size()>0){
				double max_cov=*max_element(junc_cov_s.begin(),junc_cov_s.end());
				for(int i=0;i<junc_cov_s.size();){
				    if(junc_cov_s[i]/max_cov<=COV_RATE){
					junc_l_s.erase(junc_l_s.begin()+i);
					junc_r_s.erase(junc_r_s.begin()+i);
					junc_cov_s.erase(junc_cov_s.begin()+i);
				    }
				    else i++;
				}
				}
	
	//for(int i=0;i<junc_l_s.size();i++){cout<<junc_l_s[i]<<" "<<junc_r_s[i]<<"***"<<endl;}
	//******************************************************************************************************************************2015/11/15 b
				vector<int> node_l,node_r;
				vector<double> edge_cov;
				for (int i=0;i<junc_l_s.size();i++){
				    for(int j=0;j<exon_l_s.size();j++){
					if(junc_l_s[i]-1==exon_r_s[j]) node_l.push_back(j);
	                                if(junc_r_s[i]==exon_l_s[j]) {node_r.push_back(j);edge_cov.push_back(junc_cov_s[i]);}
				    }
				}
				for(int i=0;i<false_junc.size();i++){
				    for(int j=0;j<exon_l_s.size();j++){
					if(false_junc[i]==exon_r_s[j]&&false_junc_cov[i]>=2){
					    node_l.push_back(j);node_r.push_back(j+1);edge_cov.push_back(false_junc_cov[i]);
					}
				    }
				}
				if(node_l.size()==0){
				    vector<int> pair_edge,pair_node;
//				    const string & basename = base_name();
	                            const string name = "./RawGraphs/" + basename + ".rg";
	                            save_debug(name + ".debug",gene_l,junc_l_s,junc_r_s,junc_cov_s,exon_l_s,exon_r_s,v_exon_cov_s,pair_edge,pair_node,ch_note.back(),false_junc,false_junc_cov,v_Gene,Read,READ_LENGTH,out_name,cov_filter,strand,line,XS_plus,XS_minus);
	/*
				    ofstream out_exon1("Exon.txt",ios::app);
	                    for(int m=0;m<exon_l_s.size();m++)
	                        out_exon1<<ch_note.back()<<" "<<exon_l_s[m]<<" "<<exon_r_s[m]<<" "<<v_exon_cov_s[m]<<endl;
	                    out_exon1.close();
				    ofstream out_Gene("Gene.txt",ios::app);
	                        for(int m=0;m<exon_l_s.size();m++){
	                            for(int a=exon_l_s[m]-gene_l;a<=exon_r_s[m]-gene_l;a++)
	                                out_Gene<<v_Gene[a]<<" ";
	                            out_Gene<<endl;
	                        }
	                        out_Gene.close();
	*/
	
				}
	//cout<<"here5"<<endl;
				map<int,int> node_in_all_sub;
				typedef map<int,int>::iterator ite;
				while(node_l.size()>0){//需要找连通分支
				    map<int,int> con_subgraph;
				    vector<int> exon_l_con,exon_r_con,junc_l_con,junc_r_con,false_junc_con;
				    vector<double>junc_cov_con,false_junc_cov_con,exon_cov_con;
				    con_subgraph.insert(pair<int,int> (node_l[0],1));
				    con_subgraph.insert(pair<int,int> (node_r[0],1));
				    node_l.erase(node_l.begin());node_r.erase(node_r.begin());
				    for(ite it=con_subgraph.begin();it!=con_subgraph.end();it++){
					for(int i=0;i<node_l.size();){
					    if(node_l[i]==it->first || node_r[i]==it->first){
						con_subgraph.insert(pair<int,int> (node_l[i],1));
	                                        con_subgraph.insert(pair<int,int> (node_r[i],1));
	                                        node_l.erase(node_l.begin()+i);node_r.erase(node_r.begin()+i);
	                                        edge_cov.erase(edge_cov.begin()+i);
	                                        it=con_subgraph.begin();
					    }
					    else i++;
					}
				    }
				    if(con_subgraph.size()==exon_l_s.size()){//图是联通的
					for(int it=0;it<exon_l_s.size();it++) node_in_all_sub.insert(pair<int,int> (it,1));
					exon_l_con=exon_l_s;
	                                exon_r_con=exon_r_s;
	                                exon_cov_con=v_exon_cov_s;
	                                junc_l_con=junc_l_s;
	                                junc_r_con=junc_r_s;
	                                junc_cov_con=junc_cov_s;
	                                false_junc_con=false_junc;
	                                false_junc_cov_con=false_junc_cov;
				    }
				    else{
					for(ite it=con_subgraph.begin();it!=con_subgraph.end();it++){
					    int k=it->first;
					    node_in_all_sub.insert(pair<int,int> (k,1));
					    exon_l_con.push_back(exon_l_s[k]);
					    exon_r_con.push_back(exon_r_s[k]);
					    exon_cov_con.push_back(v_exon_cov_s[k]);
					    for(int i=0;i<junc_l_s.size();i++){
						if(junc_l_s[i]-1==exon_r_s[k]){
						    junc_l_con.push_back(junc_l_s[i]);
						    junc_r_con.push_back(junc_r_s[i]);
						    junc_cov_con.push_back(junc_cov_s[i]);
						}
						if(junc_l_s[i]-1>exon_r_s[k]) break;
					    }
					    for(int i=0;i<false_junc.size();i++){
						if(false_junc[i]==exon_r_s[k]){
						    false_junc_con.push_back(false_junc[i]);
						    false_junc_cov_con.push_back(false_junc_cov[i]);
						}
						//if(false_junc[i]>exon_r_s[k]) break;
					    }
					}
				    }
				    Edge_Node_Pair ENP;
				    ENP.Find_edge_node(exon_l_con,exon_r_con,junc_l_con,junc_r_con,m_id_map);
				    vector<int> pair_edge,pair_node;
				    pair_edge=ENP.get_Edge();
	                            pair_node=ENP.get_Node();
//				    const string & basename = base_name();
	                            const string name = "./RawGraphs/" + basename + ".rg";
	                            save_debug(name + ".debug",gene_l,junc_l_con,junc_r_con,junc_cov_con,exon_l_con,exon_r_con,exon_cov_con,pair_edge,pair_node,ch_note.back(),false_junc_con,false_junc_cov_con,v_Gene,Read,READ_LENGTH,out_name,cov_filter,strand,line,XS_plus,XS_minus);
				}//wahile finish
	if(exon_l_s.size()>1){
			    for(int i=0;i<exon_l_s.size();i++){
				ite index;
				index=node_in_all_sub.find(i);
				if(index==node_in_all_sub.end()&&exon_r_s[i]-exon_l_s[i]>=250&&v_exon_cov_s[i]>3){
				   // cout<<"&& "<<i<<endl;
//				    const string & basename = base_name();
	                            const string name = "./RawGraphs/" + basename + ".rg";
				    vector<int>exon_l_con,exon_r_con,junc_l_con,junc_r_con,false_junc_con,pair_edge,pair_node;
				    vector<double>exon_cov_con,junc_cov_con,false_junc_cov_con;
	 			    exon_l_con.push_back(exon_l_s[i]);
				    exon_r_con.push_back(exon_r_s[i]);
				    exon_cov_con.push_back(v_exon_cov_s[i]);
				    save_debug(name + ".debug",gene_l,junc_l_con,junc_r_con,junc_cov_con,exon_l_con,exon_r_con,exon_cov_con,pair_edge,pair_node,ch_note.back    (),false_junc_con,false_junc_cov_con,v_Gene,Read,READ_LENGTH,out_name,cov_filter,strand,line,XS_plus,XS_minus);
				}
			    }
	}
			    }//if(exon_l_s.size()>1 || (exon_l_s.size()==1&&v_exon_cov_s[0]>3&&exon_r_s[0]-exon_l_s[0]>=500))finish
			}//for every gene finish
		    }//if(count!=0) afinish
}

	
void process_unstrand_gene(int count,vector<int> exon_l,vector<int> exon_r,vector<int> junc_l,vector<int>junc_r,vector<int> seg_l,vector<int> seg_r,vector<int> seg_NH,vector<double> exon_cov,vector<double> junc_cov,vector<double> v_Gene,map<vector<int>, double> Read,int READ_LENGTH,char * out_name,string cov_filter,int strand,int line,int XS_plus,int XS_minus,vector<string> ch_note,int gene_l,multimap <string,vector<string> > m_id_map,double rate,vector<int> same){
	//******************************************************************************************************11/19 up
		    int count_partial=0;
		    for(int i=1;i<exon_l.size();i++){
			if(exon_l[i]-exon_r[i-1]==1) count_partial++;
		    }
		    if(exon_l.size()>1&& count_partial>=10){
		    for(int i=0;i<exon_l.size()-1;i++){
			if(exon_r[i]-exon_l[i]+1>=200){
	    		    vector<double> exon_site;
			    for(int k=exon_l[i]-gene_l;k<=exon_r[i]-gene_l;k++){
			    	exon_site.push_back(v_Gene[k]);
			    }
			    double cov_l=0;double cov_r=0;
			    double cov_min=0;int seq_site;
			    for(int j=0;j<50;j++) cov_l=cov_l+exon_site[j];
			    for(int j=exon_site.size()-1;j>exon_site.size()-51;j--) cov_r=cov_r+exon_site[j];
			    if(cov_l<cov_r) {cov_min=cov_l;seq_site=0;}
			    else {cov_min=cov_r;seq_site=exon_site.size()-50;}
			    for(int j=50;j<=exon_site.size()-102;j++){
				double win_cov=0;
				for(int l=j;l<j+50;l++){
				    win_cov=win_cov+exon_site[l];
				}
				if(cov_min>win_cov) {cov_min=win_cov;seq_site=j;}
			    }
			    if(cov_min/cov_l<SEP_EXON_RATE && cov_min/cov_r<SEP_EXON_RATE ){
				for(int l=exon_l[i]-gene_l+seq_site;l<exon_l[i]-gene_l+seq_site+50;l++){v_Gene[l]=0;}
				exon_r=insert(exon_r,i,exon_l[i]+seq_site-1);
				exon_l=insert(exon_l,i+1,exon_l[i]+seq_site+50);
				i++;
			    }
			}
		    }
		    }
	
		    if(count==0){//没删除junction
	//cout<<"no_dele"<<endl;
			for(int i1=0;i1<exon_l.size();i1++){
	                    double  k=0.00000;
	                    for(int i2=exon_l[i1]-gene_l;i2<=exon_r[i1]-gene_l;i2++){
	                        k=k+v_Gene[i2];
	                    }
	                    double cov=k/(exon_r[i1]-exon_l[i1]+1);
	                    exon_cov.push_back(cov);
	                }
	
			if(exon_l.size()>1 || (exon_l.size()==1&&exon_cov[0]>3&&exon_r[0]-exon_l[0]>=250)){
			const string & basename = base_name();
	//*********************************************************************************************************2015//11//15 u
	//for(int i=0;i<exon_l.size();i++) cout<<exon_l[i]<<" "<<exon_r[i]<<endl;
			if(exon_l.size()>1){
	           	     for(int i=1;i<exon_l.size()-1;){
	                	 if((exon_l[i]-exon_r[i-1]==1|| exon_l[i+1]-exon_r[i]==1)&&!is_in(exon_l[i],junc_r)&&!is_in(exon_r[i]+1,junc_l)&&(exon_cov[i]<10)){
	                    	     exon_l.erase(exon_l.begin()+i);
	                   	     exon_r.erase(exon_r.begin()+i);
				     exon_cov.erase(exon_cov.begin()+i);
	                    	}
	               		 else i++;
	        	    }
		        }
	
	//for(int i=0;i<exon_l.size();i++) cout<<exon_l[i]<<" --- "<<exon_r[i]<<endl;
			    vector<int> false_junc;
	                    vector<double> false_junc_cov;
	                    false_junc=False_junc(exon_l,exon_r);
	                    if(false_junc.size()>0){false_junc_cov=False_junc_cov(false_junc,seg_l,seg_r,seg_NH);}
			    for(int i=0;i<false_junc.size();){
				if(false_junc_cov[i]<2){
				    false_junc.erase(false_junc.begin()+i);
				    false_junc_cov.erase(false_junc_cov.begin()+i);
				}
				else i++;
			    }
			    for(int i=0;i<false_junc.size();i++){
				if(is_in(false_junc[i],same)) false_junc_cov[i]=false_junc_cov[i]*rate;
			    }
	//for(int i=0;i<junc_l.size();i++){cout<<junc_l[i]<<" "<<junc_r[i]<<"*************"<<endl;}
	//for(int i=0;i<false_junc.size();i++){cout<<false_junc[i]<<endl;}cout<<endl;
			    if(junc_l.size()>0){
			    for(int i=0;i<false_junc.size();i++){
				for(int j=junc_l.size()-1;j>0;j--){
				    if(false_junc[i]+1<=junc_l[j] && false_junc[i]+1>junc_l[j-1]){
	//cout<<false_junc[i]<<" %%"<<endl;
					junc_l=insert(junc_l,j,false_junc[i]+1);
					junc_r=insert(junc_r,j,false_junc[i]+1);
					junc_cov=insert_d(junc_cov,j,false_junc_cov[i]);
					break;
				    }
				}
			    
				if(false_junc[i]+1>junc_l.back()){
				    junc_l.push_back(false_junc[i]+1);
				    junc_r.push_back(false_junc[i]+1);
				    junc_cov.push_back(false_junc_cov[i]);
				}
				if(false_junc[i]+1<=junc_l[0]){
	//cout<<false_junc[i]<<" %%"<<endl;
				     junc_l=insert(junc_l,0,false_junc[i]+1);
	                             junc_r=insert(junc_r,0,false_junc[i]+1);
	                             junc_cov=insert_d(junc_cov,0,false_junc_cov[i]);
				}
			    }
			    
			    }
	//for(int i=0;i<junc_l.size();i++){cout<<junc_l[i]<<" "<<junc_r[i]<<"&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&"<<endl;}
			    vector<int> partial_junc=false_junc;
			    false_junc.clear();false_junc_cov.clear();
	 		    vector<int> junc_l_cur=junc_l;vector<int>junc_r_cur=junc_r; vector<double> junc_cov_cur=junc_cov;
			if(count_partial>=10){
	    		    for(int k=0;k<junc_l.size();k++){
				if(junc_cov[k]<=35){
				    int exon_l_num=juncl_in_exon(junc_l[k],exon_l,exon_r);
				    int exon_r_num=juncr_in_exon(junc_r[k],exon_l,exon_r);
				    Exon_edge Left_exon;
				    Left_exon.find_exon_edge(exon_l_num,exon_l,exon_r,junc_l,junc_r,junc_cov,false_junc,false_junc_cov);
				    vector<int> LIn_junc_l,LIn_junc_r,LOut_junc_l,LOut_junc_r;
				    vector<double> LIn_junc_cov,LOut_junc_cov;
				    LIn_junc_l=Left_exon.get_In_junc_l();
	           	            LIn_junc_r=Left_exon.get_In_junc_r();
	            		    LIn_junc_cov=Left_exon.get_In_junc_cov();
		                    LOut_junc_l=Left_exon.get_Out_junc_l();
	            	    	    LOut_junc_r=Left_exon.get_Out_junc_r();
		                    LOut_junc_cov=Left_exon.get_Out_junc_cov();
				    Exon_edge Right_exon;
		                    Right_exon.find_exon_edge(exon_r_num,exon_l,exon_r,junc_l,junc_r,junc_cov,false_junc,false_junc_cov);
	            		    vector<int> RIn_junc_l,RIn_junc_r,ROut_junc_l,ROut_junc_r;
		                    vector<double> RIn_junc_cov,ROut_junc_cov;
	            		    RIn_junc_l=Right_exon.get_In_junc_l();
		                    RIn_junc_r=Right_exon.get_In_junc_r();
	               		    RIn_junc_cov=Right_exon.get_In_junc_cov();
			            ROut_junc_l=Right_exon.get_Out_junc_l();
	            		    ROut_junc_r=Right_exon.get_Out_junc_r();
		                    ROut_junc_cov=Right_exon.get_Out_junc_cov();
				    if(LOut_junc_l.size()==1 && LIn_junc_l.size()>0){
					double In_cov=0;
					for(int t=0;t<LIn_junc_l.size();t++){In_cov=In_cov+LIn_junc_cov[t];}
					double rate=junc_cov[k]/In_cov;
					if(rate<RATE){
					    junc_l_cur[k]=0;
					    junc_r_cur[k]=0;
					    junc_cov_cur[k]=0;
					}
				    }
				    if(RIn_junc_l.size()==1 && ROut_junc_l.size()>0){
					double Out_cov=0;
					for(int t=0;t<ROut_junc_l.size();t++){Out_cov=Out_cov+ROut_junc_cov[t];}
					double rate=junc_cov[k]/Out_cov;
					if(rate<RATE){
					    junc_l_cur[k]=0;
					    junc_r_cur[k]=0;
	                                    junc_cov_cur[k]=0;
					}
				    }
				    if(LOut_junc_l.size()>=2 && is_in(LOut_junc_l[0]-1,partial_junc)){
				 	double partial_cov;
					for(int t=0;t<LOut_junc_l.size();t++){
	                                    if(LOut_junc_r[t]==LOut_junc_l[t]) partial_cov=LOut_junc_cov[t];
	                                }
					if(junc_cov[k]/partial_cov<Mul_RATE){
					    junc_l_cur[k]=0;
	                                    junc_r_cur[k]=0;
	                                    junc_cov_cur[k]=0;
					}
				    }
				    if(RIn_junc_l.size()>=2 && is_in(RIn_junc_r[0]-1,partial_junc)){
					double partial_cov;
					for(int t=0;t<RIn_junc_l.size();t++){
	                                    if(RIn_junc_l[t]==RIn_junc_r[t]) partial_cov=RIn_junc_cov[t];
	                                }
				 	if(junc_cov[k]/partial_cov<Mul_RATE){
	                                    junc_l_cur[k]=0;
	                                    junc_r_cur[k]=0;
	                                    junc_cov_cur[k]=0;
	                                }
				    }
				}
			    }
			}
			    for(int t=0;t<junc_l_cur.size();){
				if(junc_l_cur[t]==0){
				    junc_l_cur.erase(junc_l_cur.begin()+t);
				    junc_r_cur.erase(junc_r_cur.begin()+t);
				    junc_cov_cur.erase(junc_cov_cur.begin()+t);
				    
				}
				else t++;
			    }
			    junc_l=junc_l_cur;junc_r=junc_r_cur;junc_cov=junc_cov_cur;
	
			    if(junc_cov.size()>0){
				double max_cov=*max_element(junc_cov.begin(),junc_cov.end());
	                        for(int i=0;i<junc_cov.size();){
	                            if(junc_cov[i]/max_cov<=COV_RATE){
	                                junc_l.erase(junc_l.begin()+i);
	                                junc_r.erase(junc_r.begin()+i);
	                                junc_cov.erase(junc_cov.begin()+i);
	                            }
	                            else i++;
	                        }
	
			    }
	
	//for(int i=0;i<junc_l.size();i++)cout<<junc_l[i]<<" "<<junc_r[i]<<endl;
	//*********************************************************************************************************2015//11//15 b
			    vector<int> node_l,node_r;
			    vector<double> edge_cov;
			    for (int i=0;i<junc_l.size();i++){
	            		 for(int j=0;j<exon_l.size();j++){
		                    if(junc_l[i]-1==exon_r[j]) node_l.push_back(j);
	            	            if(junc_r[i]==exon_l[j]) {node_r.push_back(j);edge_cov.push_back(junc_cov[i]);}
	        	        }
	        	    }
		            for(int i=0;i<false_junc.size();i++){
	        	    	for(int j=0;j<exon_l.size();j++){
		                    if(false_junc[i]==exon_r[j]&&false_junc_cov[i]>=2){node_l.push_back(j);node_r.push_back(j+1);edge_cov.push_back(false_junc_cov[i]);}
	            		}
	        	    }
			    if(node_l.size()==0){
				vector<int> pair_edge,pair_node;
//				const string & basename = base_name();
	                        const string name = "./RawGraphs/" + basename + ".rg";
	                        save_debug(name + ".debug",gene_l,junc_l,junc_r,junc_cov,exon_l,exon_r,exon_cov,pair_edge,pair_node,ch_note.back(),false_junc,false_junc_cov,v_Gene,Read,READ_LENGTH,out_name,cov_filter,strand,line,XS_plus,XS_minus);
			    }
			    map<int,int> node_in_all_sub;
			    typedef map<int,int>::iterator ite;
			    while(node_l.size()>0){//需要找连通分支
				map<int,int> con_subgraph;
				vector<int> exon_l_con,exon_r_con,junc_l_con,junc_r_con,false_junc_con;
				vector<double>junc_cov_con,false_junc_cov_con,exon_cov_con;
				con_subgraph.insert(pair<int,int> (node_l[0],1));
				con_subgraph.insert(pair<int,int> (node_r[0],1));
				node_l.erase(node_l.begin());node_r.erase(node_r.begin());
				for(ite it=con_subgraph.begin();it!=con_subgraph.end();it++){
			   	   for(int i=0;i<node_l.size();){
					if(node_l[i]==it->first || node_r[i]==it->first){
					    con_subgraph.insert(pair<int,int> (node_l[i],1));
					    con_subgraph.insert(pair<int,int> (node_r[i],1));
					    node_l.erase(node_l.begin()+i);node_r.erase(node_r.begin()+i);
					    edge_cov.erase(edge_cov.begin()+i);
					    it=con_subgraph.begin();
					}
					else i++;
				   }
				}
				if(con_subgraph.size()==exon_l.size()){//图是联通的
				    for(int it=0;it<exon_l.size();it++)node_in_all_sub.insert(pair<int,int> (it,1));
				    exon_l_con=exon_l;
				    exon_r_con=exon_r;
				    exon_cov_con=exon_cov;
				    junc_l_con=junc_l;
				    junc_r_con=junc_r;
				    junc_cov_con=junc_cov;
				    false_junc_con=false_junc;
				    false_junc_cov_con=false_junc_cov;
				}
				else{
				    for(ite it=con_subgraph.begin();it!=con_subgraph.end();it++){
				    	 int k=it->first;
					 node_in_all_sub.insert(pair<int,int> (k,1));
				    	 exon_l_con.push_back(exon_l[k]);
				    	 exon_r_con.push_back(exon_r[k]);
				    	 exon_cov_con.push_back(exon_cov[k]);
				    	 for(int i=0;i<junc_l.size();i++){
					     if(junc_l[i]-1==exon_r[k]){junc_l_con.push_back(junc_l[i]);junc_r_con.push_back(junc_r[i]);junc_cov_con.push_back(junc_cov[i]);}
				 	     if(junc_l[i]-1>exon_r[k]) break;    
				         }
				         for(int i=0;i<false_junc.size();i++){
					     if(false_junc[i]==exon_r[k]){false_junc_con.push_back(false_junc[i]);false_junc_cov_con.push_back(false_junc_cov[i]);}
				     	 }
				    }
				}
				Edge_Node_Pair ENP;
	                        ENP.Find_edge_node(exon_l_con,exon_r_con,junc_l_con,junc_r_con,m_id_map);
	                        vector<int> pair_edge,pair_node;
	                        pair_edge=ENP.get_Edge();
	                        pair_node=ENP.get_Node();
//				const string & basename = base_name();
				const string name = "./RawGraphs/" + basename + ".rg";
				save_debug(name + ".debug",gene_l,junc_l_con,junc_r_con,junc_cov_con,exon_l_con,exon_r_con,exon_cov_con,pair_edge,pair_node,ch_note.back(),false_junc_con,false_junc_cov_con,v_Gene,Read,READ_LENGTH,out_name,cov_filter,strand,line,XS_plus,XS_minus);
			    }
	if(exon_l.size()>1){
			    for(int i=0;i<exon_l.size();i++){
				ite index;
				index=node_in_all_sub.find(i);
				if(index==node_in_all_sub.end()&&exon_r[i]-exon_l[i]>=250&&exon_cov[i]>3){
//				    const string & basename = base_name();
	                            const string name = "./RawGraphs/" + basename + ".rg";
	                            vector<int>exon_l_con,exon_r_con,junc_l_con,junc_r_con,false_junc_con,pair_edge,pair_node;
	                            vector<double>exon_cov_con,junc_cov_con,false_junc_cov_con;
	                            exon_l_con.push_back(exon_l[i]);
	                            exon_r_con.push_back(exon_r[i]);
	                            exon_cov_con.push_back(exon_cov[i]);
	                            save_debug(name + ".debug",gene_l,junc_l_con,junc_r_con,junc_cov_con,exon_l_con,exon_r_con,exon_cov_con,pair_edge,pair_node,ch_note.back    (),false_junc_con,false_junc_cov_con,v_Gene,Read,READ_LENGTH,out_name,cov_filter,strand,line,XS_plus,XS_minus);
				}
			    }
	}
			}
		    }
}
