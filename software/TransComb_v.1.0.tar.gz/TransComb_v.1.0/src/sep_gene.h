#include<vector>
using namespace std;
int junc_l_exon_left_bound(int junc_l,vector<int> exon_l,vector<int> exon_r){
	for(int i=0;i<exon_l.size();i++){
		if(junc_l-1==exon_r[i]) return exon_l[i];
	}
        return 0;
}
int junc_r_exon_right_bound(int junc_r,vector<int> exon_l,vector<int> exon_r){
	for(int i=0;i<exon_l.size();i++){
		if(junc_r==exon_l[i]) return exon_r[i];
	}
	return 0;
}
class sep_gene{
	private: vector<int> gene_l,gene_r;
	public:
	 	  void find_gene_bound(vector<int> junc_l,vector<int> junc_r,vector<int> exon_l,vector<int> exon_r);
		  vector<int> get_gene_l();
 		  vector<int> get_gene_r();
};
    void  sep_gene::find_gene_bound(vector<int> junc_l,vector<int> junc_r,vector<int> exon_l,vector<int> exon_r){
	vector<int> v_sep_l,v_sep_r;
	if(junc_l.size()>0)
	{
	    v_sep_l.push_back(junc_l_exon_left_bound(junc_l[0],exon_l,exon_r));
	    int Max=0;
	    for(int i=0;i<junc_l.size();i++)
	    {
		int junc_right_exon_bound=junc_r_exon_right_bound(junc_r[i],exon_l,exon_r);
		if(Max < junc_right_exon_bound) Max=junc_right_exon_bound;
		if(i==junc_l.size()-1 || junc_l[i+1]-1> Max)
		{
		    v_sep_r.push_back(Max);
		    if(i!=junc_l.size()-1) v_sep_l.push_back(junc_l_exon_left_bound(junc_l[i+1],exon_l,exon_r));
		    Max=0;
		}
	    }
	    vector<int> v_nu_exon;
	    v_nu_exon.push_back(0);
	    for(int k=v_nu_exon.back();k<exon_l.size();k++){
		if(exon_r[k]<v_sep_l[0]){
		    gene_l.push_back(exon_l[k]);
		    gene_r.push_back(exon_r[k]);
		    v_nu_exon.push_back(k+1);
		}
		if(exon_l[k]>=v_sep_l[0]) break;
	    }
	    gene_l.push_back(v_sep_l[0]);
            gene_r.push_back(v_sep_r[0]);
	    for(int i=1;i<v_sep_l.size();i++)
	    {
//		gene_l.push_back(v_sep_l[i]);
//		gene_r.push_back(v_sep_r[i]);
		for(int j=v_nu_exon.back();j<exon_l.size();j++)
 		{
		    if(exon_l[j]>v_sep_r[i-1] && exon_r[j]< v_sep_l[i])
		    {
			gene_l.push_back(exon_l[j]);
			gene_r.push_back(exon_r[j]);
			v_nu_exon.push_back(j+1);
		    }
		    if(exon_l[j]>=v_sep_l[i]) break;
		}
		gene_l.push_back(v_sep_l[i]);
                gene_r.push_back(v_sep_r[i]);
	    }
	    for(int k=v_nu_exon.back();k<exon_l.size();k++){
                if(exon_l[k]>v_sep_r.back()){
                    gene_l.push_back(exon_l[k]);
                    gene_r.push_back(exon_r[k]);
                }
	    }
	}
	else
	{
		for(int k=0;k<exon_l.size();k++){
		    gene_l.push_back(exon_l[k]);
		    gene_r.push_back(exon_r[k]);
		}
	}
    } 
    vector<int> sep_gene::get_gene_l(){return gene_l;}
   vector<int> sep_gene::get_gene_r(){return gene_r;}
