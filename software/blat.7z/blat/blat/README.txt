This directory contains the Blat application for stand-alone use.

Please note that the Blat source and executables are freely available for
academic, nonprofit and personal use. Commercial licensing information is
available on the Kent Informatics website (http://www.kentinformatics.com/).

For help installing and running Blat please see:

- Documentation: http://genome.ucsc.edu/goldenPath/help/blatSpec.html

- FAQs: http://genome.ucsc.edu/FAQ/FAQblat.html
