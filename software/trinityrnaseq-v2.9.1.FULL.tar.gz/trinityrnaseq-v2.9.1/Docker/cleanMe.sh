sudo rm -rf ./trinity_out_dir
sudo rm -rf ./trinity_ext_sample_data
