#!/bin/bash

make CXX=g++ CC=gcc
make plugins CXX=g++ CC=gcc
