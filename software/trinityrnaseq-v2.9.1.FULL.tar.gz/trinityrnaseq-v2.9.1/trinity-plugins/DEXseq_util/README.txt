these scripts come as part of the bioconductor DEXseq package:
http://bioconductor.org/packages/release/bioc/html/DEXSeq.html

and are included here to simplify integration w/ trinity

