#ifndef __COMMON__
#define __COMMON__

enum VERBOSITY { none, info, debug };

extern VERBOSITY VERBOSE;


#endif

