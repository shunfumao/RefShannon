# Contributing to Trinity

## Branches

* The `devel` branch is for development. It's where we work on the next major release. It's also default branch for a pull request. It's what GitHub shows if you go to [trinityrnaseq/trinityrnaseq](https://github.com/trinityrnaseq/trinityrnaseq).
* The `master` branch is where we work on the next patch release.

## Testing

When you want to contribute, send pull-request and check Travis CI is passed.




